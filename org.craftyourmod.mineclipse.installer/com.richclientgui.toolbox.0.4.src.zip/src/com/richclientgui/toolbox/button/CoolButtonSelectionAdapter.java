package com.richclientgui.toolbox.button;
/**
 * @author Code Crofter
 * On behalf Polymorph Systems
 * 
 * @since RCP Toolbox v0.1 <br>
 */
public class CoolButtonSelectionAdapter implements CoolButtonSelectionListener{

	public void selectionOnPress(CoolButtonSelectionEvent e) {}

	public void selectionOnRelease(CoolButtonSelectionEvent e) {}

}
