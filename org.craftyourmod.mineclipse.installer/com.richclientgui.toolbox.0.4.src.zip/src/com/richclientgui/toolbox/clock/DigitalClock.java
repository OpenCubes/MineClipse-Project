package com.richclientgui.toolbox.clock;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Layout;
/**
 * A digital clock\timer widget. Can be used as a 12 or 24 hour clock, or as a time counter.
 * <br><br>
 * This digital clock will approximate the current time based on System if in the CLOCK_12_HOURS or 
 * CLOCK_24_HOURS behaviour.
 * <br>
 * Note: the digits on the clock can be modified by clicking in the top (increase) or bottom (decrease) halves
 * of each digit.
 * <br>
 * 
 * @author Code Crofter
 * On behalf Polymorph Systems
 * 
 * @since RCP Toolbox v0.1 <br>
 */
public class DigitalClock extends Composite{
	/** An enum used to indicate the possible styles or behviours that this digital clock can have. */
	public static enum CLOCK_STYLE{
		/** Style used for using the class as a Clock, 24 hours will not show AM or PM */
		CLOCK_24_HOURS,
		/** Style used for using the class as a Clock, 12 hours will make the use of AM and PM */
		CLOCK_12_HOURS,
		/** Style used for using the class as a Counter*/
		COUNTER;		
	}
	/** The period that will be used to approximate 1s */
	private static final int SECOND_PERIOD = 1000;
	/** The current style of the clock as specified*/
	private final CLOCK_STYLE currentStyle;
	/** The current period of the day, am or pm*/
	private int currentAM_PM;
	/** The timer used to increment the clock or timer */
	private final Timer timer = new Timer();
	/** The timer task used to increment the timer */
	private TimerTask timerTask = new DigitalClockTimer();
	/** The label that has been clicked upon */
	private Label currentClickedLabel;
	/** The label depicting the most significant hour digit */
	private final Label hourMSLbl;
	/** The label depicting the least significant hour digit */
	private final Label hourLSLbl;
	/** The label depicting the most significant minute digit */
	private final Label minuteMSLbl;
	/** The label depicting the least significant minute digit */
	private final Label minuteLSLbl;
	/** The label depicting the most significant second digit */
	private final Label secondMSLbl;
	/** The label depicting the least significant second digit */
	private final Label secondLSLbl;
	/** The label depicting the am or pm of the day */
	private final Label am_pm_Lbl;
	/** The label that indicates the first colon, between hours and minutes */
	private Label lbl1;
	/** The label that indicates the second colon, between minutes and seconds */
	private Label lbl2;	
	/** The current most significant second digit */
	private int secondsMS = 0;
	/** The current least significant second digit */
	private int secondsLS = 0;	
	/** The current most significant minute digit */	
	private int minutesMS = 0;
	/** The current least significant minute digit */
	private int minutesLS = 0;	
	/** The current most significant hour digit */
	private int hoursMS = 0;
	/** The current least significant hour digit */
	private int hoursLS = 0;	
	/** The cursor used for the increment of the clock digits */
	private final Cursor upCursor;
//			ToolBoxImageRegistry.getImage(ToolBoxImageRegistry.CURSOR_UP).getImageData(),8,0);
	/** The cursor used for the decrement of the clock digits */
	private final Cursor downCursor;
//			ToolBoxImageRegistry.getImage(ToolBoxImageRegistry.CURSOR_DOWN).getImageData(),8,15);
	/** The flag indicating that some label has been clicked */
	private boolean clicked = false;
	/** The flag indicating that the mouse when down on the top half of a digit */
	private boolean top = false;
	/** The color indicating the timer digit has been clicked on for a increment or decrement */
	private Color highlightColor;
	
	/**
	 * This will construct a digital clock based on the behaviour/style enum that is passed to it.
	 * 
	 * @param parent
	 * @param style - this is the SWT default style bits that one can set, this isn't explicitly handled but can 
	 * be useful. For example to put a border around this widget one can still specify SWT.BORDER.
	 * @param behaviour - This is an enum used to specify the behaviour of the digital clock.
	 */
	public DigitalClock(Composite parent, int style, CLOCK_STYLE behaviour){
		this(parent,style,behaviour,new Cursor(Display.getDefault(),SWT.CURSOR_ARROW), new Cursor(Display.getDefault(),SWT.CURSOR_ARROW));
	}
	
	/**
	 * 
	 * @param parent
	 * @param style - this is the SWT default style bits that one can set, this isn't explicitly handled but can 
	 * be useful. For example to put a border around this widget one can still specify SWT.BORDER.
	 * @param behaviour - This is an enum used to specify the behaviour of the digital clock.
	 * @param upCursor - The cursor used when hovering hover the top half of any digit - to increment
	 * @param downCursor - The cursor used when hovering hover the bottom half of any digit - to decrement
	 */
	public DigitalClock(Composite parent, int style, CLOCK_STYLE behaviour, Cursor upCursor, Cursor downCursor) {
		super(parent, style);
		this.upCursor = upCursor;
		this.downCursor = downCursor;
		highlightColor = Display.getDefault().getSystemColor(SWT.COLOR_GRAY);
		currentAM_PM = Calendar.getInstance().get(Calendar.AM_PM);
		currentStyle = behaviour;

		setLayout(createGridLayout());		

		hourMSLbl = createHourMSLabel();
		hourLSLbl = createHourLSLabel();

		lbl1 = createSeparatorLabel();

		minuteMSLbl = createMinuteMSLabel();
		minuteLSLbl = createMinuteLSLabel();

		lbl2 = createSeparatorLabel();

		secondMSLbl = createSecondMSLabel();
		secondLSLbl = createSecondLSLabel();

		if(currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)){
			am_pm_Lbl = createAMPMLabel();
		}else{
			am_pm_Lbl = null;
		}

		if(currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS) || 
				currentStyle.equals(CLOCK_STYLE.CLOCK_24_HOURS)){
			resetToCurrentTime();
		}
		
		addDisposeListener(new DisposeListener(){
			public void widgetDisposed(DisposeEvent e) {
				if(timerTask!=null){
					timerTask.cancel();
				}
				timer.cancel();	
				timer.purge();
			}
		});
	}

	private Label createAMPMLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText(currentAM_PM==Calendar.AM?"AM":"PM");
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseDown(MouseEvent e) {	
				currentClickedLabel = label;
				clicked = true;
				label.redraw();
			}
			@Override
			public void mouseUp(MouseEvent e) {				
				clicked = false;
				label.redraw();
				currentAM_PM = (currentAM_PM == Calendar.AM)?Calendar.PM:Calendar.AM;						
				updateLabels();
			}
		});
		return label;
	}

	private Label createSecondLSLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText("0");
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new ClockMouseListener(label,
				new IncDecListener(){
			public void increase(){
				incLSSeconds(false);
			}
			public void decrease(){
				decLSSeconds(false);
			}	
		}
		));
		return label;
	}

	private Label createSecondMSLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText("0");
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new ClockMouseListener(label,
				new IncDecListener(){
			public void increase(){
				incMSSeconds(false);
			}
			public void decrease(){
				decMSSeconds(false);
			}	
		}
		));
		return label;
	}

	private Label createMinuteLSLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText("0");
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new ClockMouseListener(label,
				new IncDecListener(){
			public void increase(){
				incLSMinutes(false);
			}
			public void decrease(){
				decLSMinutes(false);
			}	
		}
		));
		return label;
	}

	private Label createMinuteMSLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText("0");
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new ClockMouseListener(label,
				new IncDecListener(){
			public void increase(){
				incMSMinutes(false);
			}
			public void decrease(){
				decMSMinutes(false);
			}	
		}
		));
		return label;
	}

	private Label createSeparatorLabel() {
		final Label separator = new Label(this,SWT.NONE);
		separator.setText(":");
		return separator;
	}

	private Label createHourLSLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText("0");
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new ClockMouseListener(label,
				new IncDecListener(){
			public void increase(){
				incLSHours(false);
			}
			public void decrease(){
				decLSHours(false);
			}	
		}
		));
		return label;
	}

	private Label createHourMSLabel() {
		final Label label = new Label(this,SWT.NONE);
		label.setText("0");		
		label.addPaintListener(new IncrementLabelPaintListener(label));
		label.addMouseMoveListener(new ClockMouseMoveListener(label));
		label.addMouseListener(new ClockMouseListener(label,
				new IncDecListener(){
			public void increase(){
				incMSHours(false);
			}
			public void decrease(){
				decMSHours(false);
			}	
		}
		));
		return label;
	}

	private GridLayout createGridLayout() {
		final GridLayout gl = new GridLayout(currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)?9:8,false);
		gl.marginHeight = 0;
		gl.marginWidth = 0;
		gl.horizontalSpacing = 0;
		gl.verticalSpacing = 0;
		return gl;
	}

	/** This is the color that is used to indicate the increment or decrement (source = user) of a digit on the timer*/
	public void setHighLightColor(Color color){
		checkWidget();
		highlightColor = color;
	}
	/** Set the font of the AM/PM text when using CLOCK_12_HOURS behaviour*/
	public void setAM_PMLabelFont(Font font){
		checkWidget();		
		if(am_pm_Lbl!=null){
			am_pm_Lbl.setFont(font);
		}
		layout();
	}

	@Override
	public void setFont(Font font){
		checkWidget();		
		hourMSLbl.setFont(font);		
		hourLSLbl.setFont(font);		
		lbl1.setFont(font);		
		minuteMSLbl.setFont(font);		
		minuteLSLbl.setFont(font);		
		lbl2.setFont(font);	
		secondMSLbl.setFont(font);		
		secondLSLbl.setFont(font);
		if(am_pm_Lbl!=null){
			am_pm_Lbl.setFont(font);
		}
		layout();
	}

	@Override
	public void setBackground(Color color) {		
		checkWidget();		
		hourMSLbl.setBackground(color);		
		hourLSLbl.setBackground(color);		
		lbl1.setBackground(color);		
		minuteMSLbl.setBackground(color);		
		minuteLSLbl.setBackground(color);
		lbl2.setBackground(color);	
		secondMSLbl.setBackground(color);		
		secondLSLbl.setBackground(color);
		if(am_pm_Lbl!=null){
			am_pm_Lbl.setBackground(color);
		}
		super.setBackground(color);
		layout();
	}

	@Override
	public void setForeground(Color color){
		checkWidget();		
		hourMSLbl.setForeground(color);
		hourLSLbl.setForeground(color);		
		lbl1.setForeground(color);
		minuteMSLbl.setForeground(color);		
		minuteLSLbl.setForeground(color);
		lbl2.setForeground(color);
		secondMSLbl.setForeground(color);		
		secondLSLbl.setForeground(color);
		if(am_pm_Lbl!=null){
			am_pm_Lbl.setForeground(color);
		}
		layout();
	}

	/** Set the foreground color of the hour digits */
	public void setForegroundHours(Color color){
		checkWidget();		
		hourMSLbl.setForeground(color);
		hourLSLbl.setForeground(color);				
		layout();
	}
	/** Set the foreground color of the minutes digits */
	public void setForegroundMinutes(Color color){
		checkWidget();		
		minuteMSLbl.setForeground(color);		
		minuteLSLbl.setForeground(color);			
		layout();
	}

	/** Set the foreground color of the seconds digits */
	public void setForegroundSeconds(Color color){
		checkWidget();		
		secondMSLbl.setForeground(color);		
		secondLSLbl.setForeground(color);			
		layout();
	}
	/** Set the foreground color of the am and pm text when in CLOCK_12_HOURS mode*/
	public void setForegroundAM_PM(Color color){
		checkWidget();
		if(am_pm_Lbl!=null){
			am_pm_Lbl.setForeground(color);
		}
		layout();
	}

	@Override
	public final void setLayout(Layout layout) {	
		super.setLayout(layout);
	}

	/** Start the clock ticking */
	public void start(){
		checkWidget();
		if(timerTask!=null){
			timerTask.cancel();
		}
		timerTask = new DigitalClockTimer();
		timer.schedule(timerTask,0,SECOND_PERIOD);		
	}

	/** Stop the clock from ticking */
	public void stop(){			
		checkWidget();
		timerTask.cancel();		
	}

	/** Reset the clock to 00:00:00, when in 12_HOURS mode the hour least significant digit will be set to 1 and not 0*/
	public void reset(){			
		checkWidget();
		timerTask.cancel();
		secondsLS = 0;
		secondsMS = 0;
		minutesLS = 0;
		minutesMS = 0;
		hoursLS = currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)?1:0;
		hoursMS = 0;
		currentAM_PM = Calendar.getInstance().get(Calendar.AM_PM);
		updateLabels();	
	}
	
	/** Reset the clock to the current system time */
	public void resetToCurrentTime(){			
		checkWidget();		
		timerTask.cancel();
		final int seconds = Calendar.getInstance().get(Calendar.SECOND);
		secondsMS = seconds/10;
		secondsLS = seconds - secondsMS*10;			
		final int minutes = Calendar.getInstance().get(Calendar.MINUTE);
		minutesMS = minutes/10;
		minutesLS = minutes - minutesMS*10;		
		if(currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)){
			int hours = Calendar.getInstance().get(Calendar.HOUR);
			if(hours == 0){hours=12;}
			hoursMS = hours/10;
			hoursLS = hours - hoursMS*10;
			currentAM_PM = Calendar.getInstance().get(Calendar.AM_PM);
		}else if(currentStyle.equals(CLOCK_STYLE.CLOCK_24_HOURS)){
			final int hours = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
			hoursMS = hours/10;
			hoursLS = hours - hoursMS*10;
		}else{
			reset();
			return;
		}
		if(timerTask!=null){
			timerTask.cancel();
		}
		timerTask = new DigitalClockTimer();
		if(Calendar.getInstance().get(Calendar.SECOND) == seconds){
			timer.schedule(timerTask,SECOND_PERIOD-Calendar.getInstance().get(Calendar.MILLISECOND),SECOND_PERIOD);
		}else{
			timer.schedule(timerTask,0,SECOND_PERIOD);
		}			
		updateLabels();
	}

	/** Get the current number of hours */
	public int getHours(){
		checkWidget();
		return (hoursMS*10+hoursLS);
	}

	/** Get the current number of minutes */
	public int getMinutes(){
		checkWidget();
		return (minutesMS*10+minutesLS);
	}

	/** Get the current number of seconds*/
	public int getSeconds(){
		checkWidget();
		return (secondsMS*10+secondsLS);
	}

	/** Returns the integer value for the current AM or PM value. Note this integer represents the constant that is used 
	 * in the <code>java.util.Calendar</code> class, <code>Calendar.AM_PM</code>
	 */
	public int getAM_PM(){
		return currentAM_PM;
	}	
	
	/** Returns the current clock style used by the digital clock*/
	public CLOCK_STYLE getClockStyle(){
		return currentStyle;
	}
	
	private void incLSSeconds(boolean carry){
		secondsLS++;
		if(secondsLS > 9){
			secondsLS = 0;
			if(carry){
				incMSSeconds(true);
			}
		}	
	}

	private void incMSSeconds(boolean carry){
		secondsMS++;
		if(secondsMS > 5){
			secondsMS = 0;
			if(carry){
				incLSMinutes(true);
			}
		}	
	}

	private void incLSMinutes(boolean carry){
		minutesLS++;
		if(minutesLS > 9){
			minutesLS = 0;
			if(carry){
				incMSMinutes(true);
			}
		}	
	}

	private void incMSMinutes(boolean carry){
		minutesMS++;
		if(minutesMS > 5){
			minutesMS = 0;
			if(carry){
				incLSHours(true);
			}
		}
	}

	private void incLSHours(boolean carry){
		hoursLS++;
		if(currentStyle.equals(CLOCK_STYLE.CLOCK_24_HOURS)){
			if(hoursMS > 1 && hoursLS > 3){
				hoursLS = 0;
				if(carry){									
					incMSHours(true);
				}
			}else if(hoursLS > 9){
				hoursLS = 0;
				if(carry){				
					incMSHours(true);
				}
			}			
		}else if(currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)){
			if(hoursMS == 1 && hoursLS > 2){						
				if(carry){							
					hoursLS = 1;
					incMSHours(true);
				}else{
					hoursLS = 0;
				}
			}else if(hoursMS == 0 && hoursLS > 9){				
				if(carry){
					hoursLS = 0;
					incMSHours(true);
				}else{
					hoursLS = 1;
				}
			}else if(hoursLS > 9){
				hoursLS = 0;
				if(carry){					
					incMSHours(true);
				}
			}
		}else if(hoursLS > 9 && currentStyle.equals(CLOCK_STYLE.COUNTER)){
			hoursLS = 0;
			if(carry){
				incMSHours(true);
			}
		}	
	}

	private void incMSHours(boolean carry){		
		hoursMS++;
		if(currentStyle.equals(CLOCK_STYLE.CLOCK_24_HOURS)){
			if(hoursMS > 2){
				hoursMS = 0;
			}
			if(hoursMS > 1 && hoursLS > 3){
				hoursMS = 0;
			}
		}else if(currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)){
			if(hoursMS > 1){
				if(hoursLS > 0){
					hoursMS = 0;
					if(carry){
						currentAM_PM = (currentAM_PM == Calendar.AM)?Calendar.PM:Calendar.AM;
					}
				}else{
					hoursMS = 1;
				}
			}else if(hoursMS == 1 && hoursLS > 2 ){
				hoursMS = 0; 
			}
		}else if(hoursMS > 9 && currentStyle.equals(CLOCK_STYLE.COUNTER)){
			hoursMS = 0;
		}
	}

	private void decLSSeconds(boolean carry){
		secondsLS--;
		if(secondsLS < 0){
			secondsLS = 9;
			if(carry){
				decMSSeconds(true);
			}
		}	
	}

	private void decMSSeconds(boolean carry){
		secondsMS--;
		if(secondsMS < 0){
			secondsMS = 5;
			if(carry){
				decLSMinutes(true);
			}
		}	
	}

	private void decLSMinutes(boolean carry){
		minutesLS--;
		if(minutesLS < 0){
			minutesLS = 9;
			if(carry){
				decMSMinutes(true);
			}
		}	
	}

	private void decMSMinutes(boolean carry){
		minutesMS--;
		if(minutesMS < 0){
			minutesMS = 5;
			if(carry){
				decLSHours(true);
			}
		}
	}

	private void decLSHours(boolean carry){
		hoursLS--;
		if(hoursLS < 0 && currentStyle.equals(CLOCK_STYLE.CLOCK_24_HOURS)){
			if(hoursMS > 1){				
				hoursLS = 3;
				if(carry){									
					decMSHours(true);
				}
			}else{
				hoursLS = 9;
				if(carry){				
					decMSHours(true);
				}
			}			
		}else if(hoursLS < 0 &&currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)){
			if(hoursMS == 1){		
				hoursLS = 2;
				if(carry){									
					decMSHours(true);
				}
			}else {
				hoursLS = 9;
				if(carry){					
					decMSHours(true);
				}
			}
		}else if(hoursLS < 0 && currentStyle.equals(CLOCK_STYLE.COUNTER)){
			hoursLS = 9;
			if(carry){
				decMSHours(true);
			}
		}
	}

	private void decMSHours(boolean carry){		
		hoursMS--;
		if(hoursMS < 0 && currentStyle.equals(CLOCK_STYLE.CLOCK_24_HOURS)){
			if(hoursLS > 3){
				hoursMS = 1;
			}else{
				hoursMS = 2;
			}
		}else if(hoursMS < 0 && currentStyle.equals(CLOCK_STYLE.CLOCK_12_HOURS)){
			if(hoursLS > 2){
				hoursMS = 0;
			}else{
				hoursMS = 1;
			}
		}else if(hoursMS < 0 && currentStyle.equals(CLOCK_STYLE.COUNTER)){
			hoursMS = 9;
		}		
	}
	
	/** used to update the labels of the clock*/
	private void updateLabels(){
		secondLSLbl.setText(String.valueOf(secondsLS));
		secondMSLbl.setText(String.valueOf(secondsMS));
		minuteLSLbl.setText(String.valueOf(minutesLS));
		minuteMSLbl.setText(String.valueOf(minutesMS));
		hourLSLbl.setText(String.valueOf(hoursLS));
		hourMSLbl.setText(String.valueOf(hoursMS));	
		if(am_pm_Lbl!=null){
			am_pm_Lbl.setText(currentAM_PM==Calendar.AM?"AM":"PM");
		}
		if(clicked){
			secondLSLbl.redraw();		
			secondMSLbl.redraw();
			minuteLSLbl.redraw();
			minuteMSLbl.redraw();
			hourLSLbl.redraw();
			hourMSLbl.redraw();	
			if(am_pm_Lbl!=null){
				am_pm_Lbl.redraw();
			}
		}
	}
	
	/** Used to check if the mouse pointer is on the top half of the digit within a label.*/
	private boolean isTopRegion(int y, int h){
		return top = (y <= h/2.0);
	}
	
	/** A paint listener used to highlight the top or bottom half of each digit*/
	private class IncrementLabelPaintListener implements PaintListener{
		private final Label lbl;
		IncrementLabelPaintListener(Label lbl){
			this.lbl = lbl;
		}
		public void paintControl(PaintEvent e) {
			if(clicked && currentClickedLabel != null && currentClickedLabel.equals(lbl)){
				e.gc.setBackground(highlightColor);				
				final int h = lbl.getBounds().height;
				e.gc.fillRectangle(0,top?0:h-h/8,lbl.getBounds().width,h/8);
			}				
		}
	}
	/** The timer used to update the current time of the clock*/
	private class DigitalClockTimer extends TimerTask{		
		@Override
		public void run() {
			incLSSeconds(true);	
			Display.getDefault().asyncExec(new Runnable(){
				public void run() {
					updateLabels();
				}				
			});			
		}
	}
	/** The mouse move listener that will update the cursor */
	private class ClockMouseMoveListener implements MouseMoveListener{
		private final Label label;
		ClockMouseMoveListener(Label label){
			this.label = label;
		}
		public void mouseMove(MouseEvent e) {
			if(isTopRegion(e.y,label.getBounds().height)){
				label.setCursor(upCursor);
			}else{
				label.setCursor(downCursor);
			}	
		}
	}
	/** Mouse adapter used to update the clock when mouseDown or mouseUp events get called*/
	private class ClockMouseListener extends MouseAdapter {
		private final Label label;
		private final IncDecListener incDecListener;

		ClockMouseListener(Label label, IncDecListener incDecListener){
			this.label = label;
			this.incDecListener = incDecListener;
		}

		@Override
		public void mouseDown(MouseEvent e) {	
			clicked = true;
			currentClickedLabel = label;
			label.redraw();
		}
		@Override
		public void mouseUp(MouseEvent e) {	
			clicked = false;
			label.redraw();				
			if(isTopRegion(e.y,label.getBounds().height)){
				incDecListener.increase();
			}else{
				incDecListener.decrease();
			}
			updateLabels();
		}

	}

	/**
	 * Inner private interface used to propagate increment and decrement events 
	 * within the digital clock
	 *
	 */
	private interface IncDecListener {
		void increase();
		void decrease();
	}
}

