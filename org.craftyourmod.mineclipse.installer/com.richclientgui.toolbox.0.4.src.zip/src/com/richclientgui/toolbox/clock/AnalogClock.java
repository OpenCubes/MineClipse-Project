package com.richclientgui.toolbox.clock;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

/**
 * 
 * @author Code Crofter
 * 
 * 
 * Provide and image for the clock face. 
 * Provide points on the face the would indicate increments.
 * Provide a pivot point ... i.e center point of the face.
 * 
 * Find a way to rotate image
 * find a way to keep track of time and update according to System.getcurrentTime();
 * 
 * 
 */
public class AnalogClock extends Canvas{
	private final Image face;
	
	private final Point center = new Point(71,59);
	private final Point[] hourTicks = new Point[]{
			new Point(70,8), // 12 o'clock
			new Point(99,18), // 1
			new Point(120,38), // 2
			new Point(125,59), // 3
			new Point(115,80), // 4
			new Point(99,95),  // 5
			new Point(72,99), // 6 o'clock
			new Point(45,92), //7
			new Point(24,75), //8
			new Point(20,57), //9
			new Point(28,34), //10
			new Point(45,15)  // 11 o'clock
			};
	
	private final Point[] minuteTicks = new Point[]{};
	private int hoursIndex = 0;
	private int secondsIndex = 0;
	
	public AnalogClock(Composite parent,final Image face) {
		super(parent,SWT.NONE);
		this.face = face;
		setLayout(new FillLayout());
		final Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			@Override
			public void run() {
				Display.getDefault().syncExec(new Runnable(){
					public void run() {
						hoursIndex++;
						if(hoursIndex == 12){
							hoursIndex = 0;
						}
						redraw();						
					}
				});
			}
		}, 0,1000);
		
		addPaintListener(new PaintListener(){
			public void paintControl(PaintEvent e) {
				e.gc.setAntialias(SWT.ON);
				e.gc.drawImage(face, 0, 0);
				e.gc.drawLine(center.x, center.y, hourTicks[hoursIndex].x, hourTicks[hoursIndex].y);
			}
		});		
	}
	
	@Override
	public Point computeSize(int wHint, int hHint) {
		checkWidget();
		int width = 0, height = 0;
		if(face != null && !face.isDisposed()){
			width = face.getBounds().width;
			height = face.getBounds().height;
		}
	    if (wHint != SWT.DEFAULT) width = wHint;
	    if (hHint != SWT.DEFAULT) height = hHint; 
		return new Point(width, height);  
	}
}
