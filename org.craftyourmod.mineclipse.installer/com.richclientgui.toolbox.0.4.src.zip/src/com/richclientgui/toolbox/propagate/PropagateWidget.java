/*
 * Created on 14 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.propagate;

import org.eclipse.swt.widgets.Control;

/**
 * @author Carien van Zyl
 */
public interface PropagateWidget {
    void setEnabledOfChild(Control control, boolean enabled);
    Control [] getChildren ();
}
