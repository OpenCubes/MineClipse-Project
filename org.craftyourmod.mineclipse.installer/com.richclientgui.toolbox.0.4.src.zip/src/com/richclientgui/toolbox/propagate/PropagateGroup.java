/*
 * Created on 14 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.propagate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Widget;

/**
 * @author Carien van Zyl
 */
public class PropagateGroup extends Group implements PropagateWidget {

    private static final Logger logger = Logger.getLogger(PropagateComposite.class.getPackage().getName());
    
    /**list of controls that was disabled before the composite was set disabled.*/
    private ArrayList<Control> disabledControls = new ArrayList<Control>();
    
    private boolean propagateBackgroundColor = false;
    private final List<Control> excludePropagateBackground = new ArrayList<Control>();
    
    private boolean propagateForegroundColor = false;
    private final List<Control> excludePropagateForeground = new ArrayList<Control>();
    
    private boolean propagateFont = true;
    private final List<Control> excludePropagateFont = new ArrayList<Control>();
    

    /**
     * Constructs a new instance of this class given its parent
     * and a style value describing its behaviour and appearance.
     * <p>
     * The style value is either one of the style constants defined in
     * class <code>SWT</code> which is applicable to instances of this
     * class, or must be built by <em>bitwise OR</em>'ing together 
     * (that is, using the <code>int</code> "|" operator) two or more
     * of those <code>SWT</code> style constants. The class description
     * lists the style constants that are applicable to the class.
     * Style bits are also inherited from superclasses.
     * </p>
     *
     * @param parent <code>Composite</code>  a widget which will be the parent of the new instance (cannot be null)
     * @param style <code>int</code>  the style of widget to construct
     *
     * @exception IllegalArgumentException <ul>
     *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
     * </ul>
     * @exception SWTException <ul>
     *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
     * </ul>
     *
     * @see SWT#NO_BACKGROUND
     * @see SWT#NO_FOCUS
     * @see SWT#NO_MERGE_PAINTS
     * @see SWT#NO_REDRAW_RESIZE
     * @see SWT#NO_RADIO_GROUP
     * @see Widget#getStyle
     */
    public PropagateGroup(Composite parent, int style) {
        super(parent, style);
    }

    @Override
    public void setEnabled(boolean enable) {
        if (enable == this.getEnabled()) return;
        final Control[] childControls = this.getChildren();
        for (int i= 0; i < childControls.length; i++) {
            final Control control = childControls[i];
            if (!enable && control.isEnabled()) {
                control.setEnabled(false);
            } else if (!enable && !control.isEnabled()) {
                disabledControls.add(control);
            } else if (enable && !disabledControls.contains(control)) {
                control.setEnabled(true);
            }
        }
        if (enable) {
            disabledControls.clear();
        }
        super.setEnabled(enable);
    }
    

    @Override
    protected void checkSubclass() { /*do nothing*/ }
    
    /**
     * Method to set the enabled state of a child control.  This method is called to ensure that the child control stays disabled while the
     * group is disabled, but will be enabled with the group even though it was disabled before the group was disabled. 
     * The same is true when setting the control's enabled state to false.  I.e.  The control will not be enabled when the group is enabled even though
     * it was enabled before the group was disabled.
     *  
     * @param control <code>Control</code>  to enable/disable
     * @param enable <code>boolean</code>  the new enabled state of the child control
     * 
     * @throws IllegalArgumentException if the control is not a child of the group.
     */
    public void setEnabledOfChild(Control control, boolean enable) {
        logger.log(Level.INFO, "Set enabled state of " + control + " to " + enable);
        if (!Arrays.asList(getChildren()).contains(control))         
            throw new IllegalArgumentException("Control is not a child of this group.");
        final boolean isCompositeEnabled = this.getEnabled();
        if (isCompositeEnabled) {
            control.setEnabled(enable);
        } else if (enable) {
            disabledControls.remove(control);
        } else if (!enable) {
            disabledControls.add(control);
        }
    }
    
    /**
     * Sets the receiver's background colour to the colour specified
     * by the argument, or to the default system colour for the control
     * if the argument is null.
     * <p>
     * Note: This operation is a hint and may be overridden by the platform.
     * For example, on Windows the background of a Button cannot be changed.
     * </p>
     * <p>
     * The colour will be propagated to the child controls if {@link #propagateBackgroundColor} is <code>true</code>.  To set
     * {@link #propagateBackgroundColor} call {@link #setPropagateBackground(boolean)}.
     * </p>
     * 
     * @param color the new colour (or null)
     *
     * @exception IllegalArgumentException <ul>
     *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
     * </ul>
     * @exception SWTException <ul>
     *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
     *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
     * </ul>
     */
     @Override
     public void setBackground(Color color) {
         super.setBackground(color);
         if (!propagateBackgroundColor) return;
         
         final Control[] childControls = this.getChildren();
         for (int i= 0; i < childControls.length; i++) {
             final Control currControl = childControls[i];
             if (excludePropagateBackground.contains(currControl)) continue;
             currControl.setBackground(color);
         }
     }
     
     /**
      * Set whether the background of the composite should be propagated to the child controls.  Note that 
      * this method should be called before the background is set.
      * <p>By default the value is <code>false</code>.</p>
      * 
      * @param value <code>boolean</code>
      */
     public void setPropagateBackground(boolean value) {
         this.propagateBackgroundColor = value;
     }
     
     /**
      * @return <code>boolean</code> indicating whether the background colour will be propagated to the composite's child controls.
      */
     public boolean isPropogateBackground() {
         return this.propagateBackgroundColor;
     }
     
     /**
      * Method to exclude a specific control from the propagate background list.  In other words, if this method 
      * is called before {@link #setBackground(Color)} is called, the control, given as parameter, background will not be set with 
      * this composite's background.
      * 
      * @param control <code>Control</code>
      */
     public void excludeFromPropagateBackground(Control control) {
         excludePropagateBackground.add(control);
     }
     
     /**
      * Method to exclude specific controls from the propagate background list.  In other words, if this method 
      * is called before {@link #setBackground(Color)} is called, the list of controls, given as parameter, background will not be set with 
      * this composite's background.
      * 
      * @param control <code>List</code> of <code>Control</code>s
      */
     public void excludeFromPropagateBackground(List<Control> controls) {
         excludePropagateBackground.addAll(controls);
     }
     
     /**
      * Method to include a control, previously excluded from the propagate background list, to the propagate background list again.  
      * In other words, when {@link #setBackground(Color)} is called, this control's colour will be set with this composite's background.
      * 
      * @param control <code>Control</code>
      */
     public void includePropagateBackground(Control control) {
         excludePropagateBackground.remove(control);
     }
     
     /**
      * Method to include a list of controls, previously excluded from the propagate background list, to the propagate background list again.  
      * In other words, when {@link #setBackground(Color)} is called, this control's colour will be set with this composite's background.
      * 
      * @param controls <code>List</code> of </code>Control</code>s
      */
     public void includePropagateBackground(List<Control> controls) {
         excludePropagateBackground.removeAll(controls);
     }
     
     /**
      * Sets the receiver's foreground colour to the colour specified
      * by the argument, or to the default system colour for the control
      * if the argument is null.
      * <p>
      * Note: This operation is a hint and may be overridden by the platform.
      * </p>
      * <p>
      * The colour will be propagated to the child controls if {@link #propagateForegroundColor} is <code>true</code>.  To set
      * {@link #propagateForegroundColor} call {@link #setPropagateForeground(boolean)}.
      * </p>
      * @param color the new colour (or null)
      *
      * @exception IllegalArgumentException <ul>
      *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
      * </ul>
      * @exception SWTException <ul>
      *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
      *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
      * </ul>
      */
     @Override
     public void setForeground(Color color) {
         super.setForeground(color);
         if (!propagateForegroundColor) return;
         
         final Control[] childControls = this.getChildren();
         for (int i= 0; i < childControls.length; i++) {
             final Control currControl = childControls[i];
             if (excludePropagateForeground.contains(currControl)) continue;
             currControl.setForeground(color);
         }
     }
     
     /**
      * Set whether the foreground of the composite should be propagated to the child controls.  Note that 
      * this method should be called before the foreground is set.
      * <p>By default the value is <code>false</code>.</p>
      * 
      * @param value <code>boolean</code>
      */
     public void setPropagateForeground(boolean value) {
         this.propagateForegroundColor = value;
     }
     
     /**
      * @return <code>boolean</code> indicating whether the foreground colour will be propagated to the composite's child controls.
      */
     public boolean isPropogateForeground() {
         return this.propagateForegroundColor;
     }
     
     /**
      * Method to exclude a specific control from the propagate foreground list.  In other words, if this method 
      * is called before {@link #setForeground(Color)} is called, the control, given as parameter, foreground will not be set with 
      * this composite's foreground.
      * 
      * @param control <code>Control</code>
      */
     public void excludeFromPropagateForeground(Control control) {
         excludePropagateForeground.add(control);
     }
     
     /**
      * Method to exclude specific controls from the propagate foreground list.  In other words, if this method 
      * is called before {@link #setForeground(Color)} is called, the list of controls, given as parameter, foreground will not be set with 
      * this composite's foreground.
      * 
      * @param control <code>List</code> of <code>Control</code>s
      */
     public void excludeFromPropagateForeground(List<Control> controls) {
         excludePropagateForeground.addAll(controls);
     }
     
     /**
      * Method to include a control, previously excluded from the propagate foreground list, to the propagate foreground list again.  
      * In other words, when {@link #setForeground(Color)} is called, this control's colour will be set with this composite's foreground.
      * 
      * @param control <code>Control</code>
      */
     public void includePropagateForeground(Control control) {
         excludePropagateForeground.remove(control);
     }
     
     /**
      * Method to include a list of controls, previously excluded from the propagate foreground list, to the propagate foreground list again.  
      * In other words, when {@link #setForeground(Color)} is called, this control's colour will be set with this composite's foreground.
      * 
      * @param controls <code>List</code> of </code>Control</code>s
      */
     public void includePropagateForeground(List<Control> controls) {
         excludePropagateForeground.removeAll(controls);
     }
     
     /**
      * Sets the font that the receiver will use to paint textual information
      * to the font specified by the argument, or to the default font for that
      * kind of control if the argument is null.
      * <p>
      * The font will be propagated to the child controls if {@link #propagateFont} is <code>true</code>.  To set
      * {@link #propagateFont} call {@link #setPropagateFont(boolean)}.
      * </p>
      * @param font the new font (or null)
      *
      * @exception IllegalArgumentException <ul>
      *    <li>ERROR_INVALID_ARGUMENT - if the argument has been disposed</li> 
      * </ul>
      * @exception SWTException <ul>
      *    <li>ERROR_WIDGET_DISPOSED - if the receiver has been disposed</li>
      *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the receiver</li>
      * </ul>
      */
     @Override
     public void setFont(Font font) {
         super.setFont(font);
         if (!propagateFont) return;
         
         final Control[] childControls = this.getChildren();
         for (int i= 0; i < childControls.length; i++) {
             final Control currControl = childControls[i];
             if (excludePropagateFont.contains(currControl)) continue;
             currControl.setFont(font);
         }
     }
     
     /**
      * Set whether the font of the composite should be propagated to the child controls.  Note that 
      * this method should be called before the font is set.
      * <p>By default the value is <code>true</code>.</p>
      * 
      * @param value <code>boolean</code>
      */
     public void setPropagateFont(boolean value) {
         this.propagateFont = value;
     }
     
     /**
      * @return <code>boolean</code> indicating whether the font will be propagated to the composite's child controls.
      */
     public boolean isPropogateFont() {
         return this.propagateFont;
     }
     
     /**
      * Method to exclude a specific control from the propagate font list.  In other words, if this method 
      * is called before {@link #setFont(Font)} is called, the control, given as parameter, font will not be set with 
      * this composite's font.
      * 
      * @param control <code>Control</code>
      */
     public void excludeFromPropagateFont(Control control) {
         excludePropagateFont.add(control);
     }
     
     /**
      * Method to exclude specific controls from the propagate font list.  In other words, if this method 
      * is called before {@link #setFont(Font)} is called, the list of controls, given as parameter, font will not be set with 
      * this composite's font.
      * 
      * @param control <code>List</code> of <code>Control</code>s
      */
     public void excludeFromPropagateFont(List<Control> controls) {
         excludePropagateFont.addAll(controls);
     }
     
     /**
      * Method to include a control, previously excluded from the propagate font list, to the propagate font list again.  
      * In other words, when {@link #setFont(Font)} is called, this control's font will be set with this composite's font.
      * 
      * @param control <code>Control</code>
      */
     public void includePropagateFont(Control control) {
         excludePropagateFont.remove(control);
     }
     
     /**
      * Method to include a list of controls, previously excluded from the propagate font list, to the propagate font list again.  
      * In other words, when {@link #setFont(Font)} is called, this control's font will be set with this composite's font.
      * 
      * @param controls <code>List</code> of </code>Control</code>s
      */
     public void includePropagateFont(List<Control> controls) {
         excludePropagateFont.removeAll(controls);
     }

}
