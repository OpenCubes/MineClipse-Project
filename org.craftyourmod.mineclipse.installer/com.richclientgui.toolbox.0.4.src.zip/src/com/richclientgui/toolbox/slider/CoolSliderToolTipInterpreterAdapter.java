package com.richclientgui.toolbox.slider;
/**
 * An adapter of the interface <code>CoolSliderToolTipInterperter</code>
 * 
 * @author Code Crofter <br>
 * On behalf Polymorph Systems
 *
 * @since RCP Toolbox v0.1 <br>
 */
public class CoolSliderToolTipInterpreterAdapter implements CoolSliderToolTipInterpreter{

	public String getToolTipForPositionOnMouseHover(double percentage) {		
		return null;
	}

	public String getToolTipForPositionOnMouseMoveOver(double percentage) {	
		return null;
	}

}
