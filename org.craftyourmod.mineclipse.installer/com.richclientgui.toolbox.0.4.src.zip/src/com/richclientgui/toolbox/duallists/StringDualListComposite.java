/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.duallists;

import java.util.List;

import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.widgets.Composite;

/**
 * This class is a <code>DualTableViewerComposite</code> created to simplify the creation of <code>DualTableViewer</code>s that 
 * only contain string elements.
 * 
 * By using this class, it is not necessary to set the labelProviders, contentProviders or sorters.  The lists will automatically 
 * be sorted.  To disable sorting, call {@link #setIsSorted(false)}.
 * 
 * @author Carien van Zyl
 */
public class StringDualListComposite extends DualListComposite<String> {

    /**
     * Constructor
     * 
     * @param parent <code>Composite</code>
     * @param style <code>int</code>
     * @param initialAvailableItems <code>List</code> of initial items in the available list.  The items should be of type <code>String</code>.
     * @param initialChosenItems <code>List</code> of initial items in the chosen list.  The items should be of type <code>String</code>.
     */
    public StringDualListComposite(Composite parent, int style, List<String> initialAvailableItems, List<String> initialChosenItems) {
        super(parent, style);  
        this.setAvailableContentProvider(new RemovableContentProvider<String>(initialAvailableItems));
        this.setChosenContentProvider(new RemovableContentProvider<String>(initialChosenItems));
        this.setComparators(new ViewerComparator());
    }
    
    /**
     * @param isSorted <code>boolean</code> indicating whether the viewers should be sorted.  Default is <code>true</code>.
     */
    public void setIsSorted(boolean isSorted) {
        this.setComparators(isSorted ? new ViewerComparator() : null);
    }

}
