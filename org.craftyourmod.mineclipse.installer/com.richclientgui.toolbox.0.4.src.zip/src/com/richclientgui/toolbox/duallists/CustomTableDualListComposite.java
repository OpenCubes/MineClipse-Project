/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.duallists;

import java.util.Arrays;
import java.util.Comparator;

import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * This class is a <code>DualTableViewerComposite</code> created to simplify the creation of custom tables.
 * I.e. a custom table with custom columns can be used for each <code>TableViewer</code>.
 * <p>
 * The constructor takes in two <code>TableColumnData</code> arrays specifying the properties of the columns.  <code>TableColumnData</code> is 
 * a special class containing all the properties (including the header, index and width) of a column.  These arrays are used to construct the
 * table columns.  As with the normal <code>DualListComposite</code>, labelProviders, contentProviders, viewerComparators, viewerFilters and
 * labels can be set.
 * 
 * <T> type of objects in the tables
 * 
 * @author Carien van Zyl
 */
public class CustomTableDualListComposite<T extends Object> extends DualListComposite<T> {

    private final TableColumnData[] availableColumnData;
    private final TableColumnData[] chosenColumnData;
    
    /**
     * Constructor
     * 
     * @param parent <code>Composite</code>
     * @param style <code>int</code>
     * @param availableColumnData <code>TableColumnData[]</code>  array of <code>TableColumnData</code> specifying the 
     * columns with it's properties of the available table.
     * @param chosenColumnData <code>TableColumnData[]</code>  array of <code>TableColumnData</code> specifying the 
     * columns with it's properties of the chosen table.
     */
    public CustomTableDualListComposite(Composite parent, int style, TableColumnData[] availableColumnData, TableColumnData[] chosenColumnData) {
        super(parent,style);
        this.availableColumnData = availableColumnData == null ? new TableColumnData[] {new TableColumnData(0, "", 150)}  : availableColumnData ;
        final Comparator<TableColumnData> columnDataComparator = new Comparator<TableColumnData>() {
            public int compare(TableColumnData arg0, TableColumnData arg1) {
                return arg0.getIndex() - arg1.getIndex() ;
            }
        };
        Arrays.sort(this.availableColumnData, columnDataComparator);
        this.chosenColumnData = chosenColumnData == null ? new TableColumnData[] {new TableColumnData(0, "", 150)}  : chosenColumnData;
        if (this.chosenColumnData != null) {
            Arrays.sort(this.chosenColumnData, columnDataComparator);
        }
        createTableColumns();
    }
    
    /**
     * Creates the available table.
     */
    @Override
    protected final Table createAvailableTable(Composite parent) {
        final Table table = new Table(parent, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI | SWT.FULL_SELECTION);
        table.setLinesVisible(true);
        table.setHeaderVisible(true);
        table.setLayout(new TableLayout());
        table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        return table;
    }
    
    /**
     * Creates the chosen table.
     */
    @Override
    protected final Table createChosenTable(Composite parent) {
        final Table table = new Table(parent, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI | SWT.FULL_SELECTION);
        table.setLinesVisible(true);
        table.setHeaderVisible(true);
        table.setLayout(new TableLayout());
        table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        return table;
    }
    
    /**
     * Create the table columns of both tables from their <code>TableColumnData</code> arrays.
     */
    private void createTableColumns() {
        for (int i = 0; i < availableColumnData.length; i++) {
            createTableColumn(availableColumnData[i], getAvailableTable());
        }
        for (int i = 0; i < chosenColumnData.length; i++) {
            createTableColumn(chosenColumnData[i], getChosenTable());
        }
    }
    
    /**
     * Create a table column
     * 
     * @param columnData <code>TableColumnData</code> containing the properties of the column.
     * @param table <code>Table<code> on which the column should be created.
     */
    //TODO columnweightLayout
    private void createTableColumn(TableColumnData columnData, Table table) {
        final TableColumn col = new TableColumn(table, columnData.getColumnStyle(), columnData.getIndex());
        col.setText(columnData.getHeader()); 
        col.setMoveable(columnData.isMoveable());
        col.setWidth(columnData.getWidth());
        col.setResizable(columnData.isResizable());
        col.setAlignment(columnData.getAlignment());
        col.setToolTipText(columnData.getTooltip());
        col.setImage(columnData.getImage());
    }
}
