/*
 * Created on 14 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.duallists;

import java.util.List;

import org.eclipse.jface.viewers.IStructuredContentProvider;

/**
 * Interface for contentProviders used by the <code>DualListComposite</code>
 * 
 * <T> type of objects in the contentProvider
 * 
 * @author Carien van Zyl
 */
public interface IRemovableContentProvider<T extends Object> extends IStructuredContentProvider {
    /**
     * Remove the object from the entries.
     * 
     * @param obj <code>T</code>  object to remove.
     */
    void removeElement(T obj);
    
    /**
     * Add the object to the entries.
     * 
     * @param obj <code>T</code>  object to add.
     */
    void addElement(T obj);
    
    /**
     * Add the list of objects to the entries.
     * 
     * @param elements <code>List</code>
     */
    void addElements(List<T> elements);
    
    /**
     * Remove the list of objects to the entries.
     * 
     * @param elements <code>List</code>
     */
    void removeElements(List<T> elements);
    
    /**
     * @return the number of elements provider by the ContentProvider
     */
    int getNumberOfElements();
}
