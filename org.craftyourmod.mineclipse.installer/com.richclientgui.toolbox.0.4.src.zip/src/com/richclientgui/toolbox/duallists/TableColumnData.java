/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.duallists;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;

/**
 * Class containing the properties of a <code>TableColumn</code>.
 * 
 * @author Carien van Zyl
 */
public class TableColumnData {
    
    private int width = 50;
    private boolean resizable = true;
    private boolean moveable = false;
    private final int index;
    private String header;
    private String tooltip;
    private int columnStyle = SWT.LEFT;
    private int alignment = SWT.LEFT;
    private Image image = null;
   
    /**
     * Constructor
     * 
     * @param index <code>index<code> of column in the table
     * @param header <code>String<code>  header of column 
     * @param width <code>int</code>  width of column
     */
    public TableColumnData(int index, String header, int width) {
        this.index = index;
        this.width = width;
        this.header = header;
    }
    
    /**
     * Constructor
     * 
     * @param index <code>index<code> of column in the table
     * @param header <code>String<code>  header of column 
     * @param width <code>int</code>  width of column
     * @param tooltip <code>String</code>  tooltip of column
     * @param resizable <code>boolean</code>  
     * @param moveable <code>boolean</code>
     * @param columnStyle <code>int</code>
     * @param alignment <code>int</code>
     * @param image <code>Image</code>
     */
    public TableColumnData(int index, String header, int width, String tooltip, boolean resizable, boolean moveable,
            int columnStyle, int alignment, Image image) {
        this(index, header, width);
        this.resizable = resizable;
        this.moveable = moveable;
        this.tooltip = tooltip;
        this.columnStyle = columnStyle;
        this.alignment = alignment;
        this.image = image;
    }

    public int getWidth() {
        return width;
    }

    public boolean isResizable() {
        return resizable;
    }

    public boolean isMoveable() {
        return moveable;
    }

    public int getIndex() {
        return index;
    }

    public String getHeader() {
        return header;
    }

    public String getTooltip() {
        return tooltip;
    }

    public int getColumnStyle() {
        return columnStyle;
    }

    public int getAlignment() {
        return alignment;
    }

    public Image getImage() {
        return image;
    }

}
