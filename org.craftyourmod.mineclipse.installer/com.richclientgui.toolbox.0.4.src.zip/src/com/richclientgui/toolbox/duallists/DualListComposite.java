/*
 * Created on 14 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.duallists;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Widget;

import com.richclientgui.toolbox.propagate.PropagateComposite;

/**
 * A composite that represents a dual list.  The composite consists of three parts :
 * <ul><li>  a <code>TableViewer</code> on the left (the <code>availableTableViewer</code>)</li>
 * <li>  a <code>Composite</code> in the centre containing buttons for add, remove, add all and remove all</li>
 * <li>  a <code>TableViewer</code> on the right (the <code>chosenTableViewer)</li>
 * </ul>
 * The basic idea behind the composite is to have a list on the left side, containing all the possibilities 
 * that the user can choose from.  The user builds a list of options on the right side by using the buttons.
 * <p>
 * Properties that can be set for the table viewers.
 * <ul>
 * <li>contentproviders - {@link #setAvailableContentProvider(IRemovableContentProvider)}, and 
 * {@link #setChosenContentProvider(IRemovableContentProvider)}</li>
 * <li>labelproviders - ({@link #setAvailableLabelProvider(IBaseLabelProvider)} and {@link #setChosenLabelProvider(IBaseLabelProvider)}) or {@link #setLabelProviders(IBaseLabelProvider)}</li>
 * <li>comparators - ({@link #setAvailableViewerComparator(ViewerComparator)} and {@link #setChosenComparator(ViewerComparator)}) or {@link #setComparators(ViewerComparator)}</li>
 * <li>viewer filters - ({@link #setAvailableViewerFilter(ViewerFilter)} and {@link #setChosenViewerFilter(ViewerFilter)}</li>
 * <li>label displayed on top of the tableViewer - {@link #setViewerLabels(String, String)}</li>
 * </ul> 
 * 
 * <T> type of objects in the lists.
 * @author Carien van Zyl
 * 
 */
//TODO create with toolkit
//TODO externalise strings
public class DualListComposite<T extends Object> extends PropagateComposite {

    //properties
    private IRemovableContentProvider<T> availableContentProvider;
    private IBaseLabelProvider availableLabelProvider;
    private ViewerComparator availableComparator;
    private ViewerFilter availableViewerFilter;
    private Table availableTable;
    
    private IRemovableContentProvider<T> chosenContentProvider;
    private IBaseLabelProvider chosenLabelProvider;
    private ViewerComparator chosenComparator;
    private ViewerFilter chosenViewerFilter;
    private Table chosenTable;
    
    //widgets
    private Label lblAvailable;
    private Label lblBlank;
    private Label lblChosen;
    private TableViewer availableViewer;
    private TableViewer chosenViewer;
    
    private PropagateComposite centerComposite;
    private Button btnAdd;
    private Button btnAddAll;
    private Button btnRemove;
    private Button btnRemoveAll;
    
    //listeners
    private final java.util.List<ListContentChangedListener<T>> chosenListChangedListeners = new ArrayList<ListContentChangedListener<T>>();
    private final java.util.List<ListContentChangedListener<T>> availableListChangedListeners = new ArrayList<ListContentChangedListener<T>>();
    
    /**
     * Constructs a new instance of this class given its parent composite
     * and a style value describing its behaviour and appearance.
     * <p>
     * The style value is either one of the style constants defined in
     * class <code>SWT</code> which is applicable to instances of this
     * class, or must be built by <em>bitwise OR</em>'ing together 
     * (that is, using the <code>int</code> "|" operator) two or more
     * of those <code>SWT</code> style constants. The class description
     * lists the style constants that are applicable to the class.
     * Style bits are also inherited from superclasses.
     * </p>
     *
     * @param parent <code>Composite</code>  a widget which will be the parent of the new instance (cannot be null)
     * @param style <code>int</code>  the style of widget to construct
     *
     * @exception IllegalArgumentException <ul>
     *    <li>ERROR_NULL_ARGUMENT - if the parent is null</li>
     * </ul>
     * @exception SWTException <ul>
     *    <li>ERROR_THREAD_INVALID_ACCESS - if not called from the thread that created the parent</li>
     * </ul>
     *
     * @see SWT#NO_BACKGROUND
     * @see SWT#NO_FOCUS
     * @see SWT#NO_MERGE_PAINTS
     * @see SWT#NO_REDRAW_RESIZE
     * @see SWT#NO_RADIO_GROUP
     * @see Widget#getStyle
     */
    public DualListComposite(Composite parent, int style) {
        super(parent, style);
        createControl();
    }
    
    /**
     * Creates the dual list.
     */
    private void createControl() {
        this.setLayout(new GridLayout(3,false));
        this.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        
        //Available TableViewer
        availableTable = createAvailableTable(this);
        if (availableTable == null) {
            availableViewer = new TableViewer(this);
            availableTable = availableViewer.getTable();
            final GridData viewerGridData = new GridData(SWT.FILL, SWT.FILL, true, true);
            viewerGridData.heightHint = 100;
            viewerGridData.widthHint = 200;
            availableTable.setLayoutData(viewerGridData);
        } else {
            availableViewer = new TableViewer(availableTable);
        }
        availableLabelProvider = new LabelProvider();
        availableViewer.setLabelProvider(availableLabelProvider);
        availableViewer.setUseHashlookup(true);
        
        //Buttons between two TableViewers
        centerComposite = new PropagateComposite(this, SWT.NONE);
        final GridLayout buttonLayout = new GridLayout();
        buttonLayout.marginWidth = 2;
        buttonLayout.marginHeight = 2;
        centerComposite.setLayout(buttonLayout);
        centerComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, false, true));
        
        //Add button
        btnAdd = new Button(centerComposite, SWT.PUSH);
        btnAdd.setText("&Add");
        btnAdd.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        //Remove button
        btnRemove = new Button(centerComposite, SWT.PUSH);
        btnRemove.setText("&Remove");
        btnRemove.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        //Add All button
        btnAddAll = new Button(centerComposite, SWT.PUSH);
        btnAddAll.setText("A&dd All");
        btnAddAll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        //Remove All button
        btnRemoveAll = new Button(centerComposite, SWT.PUSH);
        btnRemoveAll.setText("Re&move All");
        btnRemoveAll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        //Chosen TableViewer
        chosenTable = createChosenTable(this);
        if (chosenTable == null) {
            chosenViewer = new TableViewer(this);
            chosenTable = chosenViewer.getTable();
            final GridData viewerGridData = new GridData(SWT.FILL, SWT.FILL, true, true);
            viewerGridData.heightHint = 100;
            viewerGridData.widthHint = 200;
            chosenTable.setLayoutData(viewerGridData);
             
        } else {
            chosenViewer = new TableViewer(chosenTable);
        }
        chosenViewer.setUseHashlookup(true);
        chosenLabelProvider = new LabelProvider();
        chosenViewer.setLabelProvider(chosenLabelProvider);
        
        addListeners();
    }
    
    /**
     * Creates the available table.  Subclasses can override to create their own tables.  
     * By default <code>null</code> will be returned.
     * 
     * @param parent <code>Composite</code> 
     * @return <code>Table</code>  <code>null</code> to not create a custom table.
     */
    protected Table createAvailableTable(Composite parent) {
        return null;
    }
    
    /**
     * Create the chosen table.  Subclasses can override to create their own tables.   By default <code>null</code> will be returned.
     * 
     * @param parent <code>Composite</code> 
     * @return <code>Table</code>  <code>null</code> to not create a custom table.
     */
    protected Table createChosenTable(Composite parent) {
        return null;
    }
    
    /**
     * Add the listeners that manages the movement of the elements between the two tables.
     */
    private void addListeners() {
        btnAdd.addSelectionListener(new SelectionAdapter() {
            @SuppressWarnings({ "unchecked" })
            @Override
            public void widgetSelected(SelectionEvent e) {
                final IStructuredSelection selection = (IStructuredSelection) availableViewer.getSelection();
                final Iterator it = selection.iterator();
                while (it.hasNext()) {
                    final Object obj = it.next();
                    availableContentProvider.removeElement((T) obj);
                    chosenContentProvider.addElement((T) obj);
                }
                refreshTableViewers();
                fireChosenListContentChangedEvent(chosenContentProvider);
                fireAvailableListContentChangedEvent(availableContentProvider);
            }
        });
        
        btnRemove.addSelectionListener(new SelectionAdapter() {
            @SuppressWarnings("unchecked")
            @Override
            public void widgetSelected(SelectionEvent e) {
                final IStructuredSelection selection = (IStructuredSelection) chosenViewer.getSelection();
                final Iterator it = selection.iterator();
                while (it.hasNext()) {
                    final Object obj = it.next();
                    availableContentProvider.addElement((T) obj);
                    chosenContentProvider.removeElement((T) obj);
                }
                refreshTableViewers();
                fireChosenListContentChangedEvent(chosenContentProvider);
                fireAvailableListContentChangedEvent(availableContentProvider);
            }
        });
        
        btnAddAll.addSelectionListener(new SelectionAdapter() {
            @SuppressWarnings("unchecked")
            @Override
            public void widgetSelected(SelectionEvent e) {
                final TableItem[] items = availableTable.getItems();
                for (int i = 0; i < items.length; i++) {
                    if (items[i] == null) continue;
                    final Object obj = items[i].getData();
                    availableContentProvider.removeElement((T) obj);
                    chosenContentProvider.addElement((T) obj);
                    
                }
                refreshTableViewers();
                fireChosenListContentChangedEvent(chosenContentProvider);
                fireAvailableListContentChangedEvent(availableContentProvider);
            }
        });
        
        btnRemoveAll.addSelectionListener(new SelectionAdapter() {
            @SuppressWarnings("unchecked")
            @Override
            public void widgetSelected(SelectionEvent e) {
                final TableItem[] items = chosenTable.getItems();
                for (int i = 0; i < items.length; i++) {
                    if (items[i] == null) continue;
                    final Object obj = items[i].getData();
                    chosenContentProvider.removeElement((T) obj);
                    availableContentProvider.addElement((T) obj);
                    
                }
                refreshTableViewers();
                fireChosenListContentChangedEvent(chosenContentProvider);
                fireAvailableListContentChangedEvent(availableContentProvider);
            }
        });
        

        //Enablement of appropriate buttons
        availableTable.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                centerComposite.setEnabledOfChild(btnAdd, availableTable.getSelectionCount() > 0);
            }
        });
        
        availableTable.addPaintListener(new PaintListener() {
            public void paintControl(PaintEvent e) {
                centerComposite.setEnabledOfChild(btnAdd, availableTable.getSelectionCount() > 0);
                centerComposite.setEnabledOfChild(btnAddAll, availableTable.getItemCount() > 0);
            }
        });

        chosenTable.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                centerComposite.setEnabledOfChild(btnRemove, chosenTable.getSelectionCount() > 0);
            }
        });
        chosenTable.addPaintListener(new PaintListener() {
            public void paintControl(PaintEvent e) {
                centerComposite.setEnabledOfChild(btnRemove, chosenTable.getSelectionCount() > 0);
                centerComposite.setEnabledOfChild(btnRemoveAll, chosenTable.getItemCount() > 0);
            }
        });
    }
    
    /**
     * Refresh both table viewers.  This method should be called whenever the elements in both tables have changed.
     */
    public void refreshTableViewers(){
        BusyIndicator.showWhile(Display.getCurrent(),new Runnable() {
            public void run() {
                availableViewer.refresh();
                chosenViewer.refresh();
            }
        });
    }
    
    /**
     * Refresh the chosen viewer.  This method should be called whenever the elements in only the chosen table have changed.
     */
    public void refreshChosenViewer() {
        BusyIndicator.showWhile(Display.getCurrent(), new Runnable() {
            public void run() {
                chosenViewer.refresh();
            }
        });
    }
    
    /**
     * Refresh the available viewer.  This method should be called whenever the elements in only the available table have changed.
     */
    public void refreshAvailableViewer() {
        BusyIndicator.showWhile(Display.getCurrent(), new Runnable() {
            public void run() {
                availableViewer.refresh();
            }
        });
    }
    
    /**
     * Method to add labels to the top of the available and chosen viewers.
     * 
     * @param availableLabel <code>String</code>  the label for the available <code>TableViewer</code>
     * @param chosenLabel <code>String</code>  the label for the chosen <code>TableViewer</code>
     */
    public void setViewerLabels(String availableLabel, String chosenLabel) {
        if (((availableLabel==null) || availableLabel.trim().equals("")) && 
                ((chosenLabel==null) || chosenLabel.trim().equals(""))) return;
        
        if (lblAvailable == null) {
            //create label widgets
            lblAvailable = new Label(this, SWT.NONE);
            lblAvailable.setText(availableLabel);
            lblAvailable.moveAbove(availableTable);
            lblBlank = new Label(this,SWT.NONE);
            lblBlank.moveBelow(lblAvailable);
            lblChosen = new Label(this, SWT.NONE);
            lblChosen.setText(chosenLabel);
            lblChosen.moveBelow(lblBlank);
        }
        lblAvailable.setText(availableLabel==null ? "" : availableLabel);
        lblChosen.setText(chosenLabel==null ? "" : chosenLabel);
    }
    
    /**
     * Sets the content provider for the available <code>TableViewer</code>.  Note that if this method is never called,
     * the available list will not contain data.
     * 
     * @param provider <code>IRemovableContentProvider</code> 
     */
    public void setAvailableContentProvider(IRemovableContentProvider<T> provider) {
        if (isEqual(provider, availableContentProvider)) return;
        availableContentProvider = provider;
        availableViewer.setContentProvider(provider);
        availableViewer.setInput(this);
    }
    
    /**
     * Sets the content provider for the chosen <code>TableViewer</code>.  Note that if this method is never called,
     * the chosen list will not contain data.
     * 
     * @param provider <code>IRemovableContentProvider</code> 
     */
    public void setChosenContentProvider(IRemovableContentProvider<T> provider) {
        if (isEqual(provider, chosenContentProvider)) return;
        chosenContentProvider = provider;
        chosenViewer.setContentProvider(provider);
        chosenViewer.setInput(this);
    }
    
    /**
     * Sets the comparator for the available <code>TableViewer</code>.  The entries will be sorted according to the 
     * comparator.  Set to </code>null</code> to not sort the entries. 
     * 
     * @param comparator <code>ViewerComparator</code>
     */
    public void setAvailableViewerComparator(ViewerComparator comparator) {
        if (isEqual(comparator, availableComparator)) return;
        availableComparator = comparator;
        availableViewer.setComparator(comparator);
    }
    
    /**
     * Sets the comparator for the chosen <code>TableViewer</code>.  The entries will be sorted according to the 
     * comparator.  Set to </code>null</code> to not sort the entries. 
     * 
     * @param comparator <code>ViewerComparator</code>
     */
    public void setChosenComparator(ViewerComparator comparator) {
        if (isEqual(comparator, chosenComparator)) return;
        chosenComparator = comparator;
        chosenViewer.setComparator(comparator);
    }
    
    /**
     * Sets the comparator for the both <code>TableViewer</code>s.  The entries will be sorted according to the 
     * comparator.  Set to </code>null</code> to not sort the entries. 
     * 
     * @param comparator <code>ViewerComparator</code>
     */
    public void setComparators(ViewerComparator comparator) {
        setAvailableViewerComparator(comparator);
        setChosenComparator(comparator);
    }
    
    /**
     * Set the labelProvider for the available <code>TableViewer</code>.  <code>LabelProvider</code> is used if 
     * the labelProvider is not set. 
     * 
     * @param labelProvider <code>IBaseLabelProvider</code>
     */
    public void setAvailableLabelProvider(IBaseLabelProvider labelProvider) {
        if (labelProvider == null) throw new IllegalArgumentException("Available label provider cannot be null.");
        if (labelProvider.equals(this.availableLabelProvider)) return;
        availableLabelProvider = labelProvider;
        availableViewer.setLabelProvider(labelProvider);
    }
    
    /**
     * Set the labelProvider for the chosen <code>TableViewer</code>.  <code>LabelProvider</code> is used if 
     * the labelProvider is not set.
     * 
     * @param labelProvider <code>IBaseLabelProvider</code>
     */
    public void setChosenLabelProvider(IBaseLabelProvider labelProvider) {
        if (labelProvider == null) throw new IllegalArgumentException("Chosen label provider cannot be null.");
        if (labelProvider.equals(this.chosenLabelProvider)) return;
        chosenLabelProvider = labelProvider;
        chosenViewer.setLabelProvider(labelProvider);
    }
    
    /**
     * Set the labelProvider of both <code>TableViewer</code>s.
     * 
     * @param labelProvider <code>IBaseLabelProvider</code>
     */
    public void setLabelProviders(IBaseLabelProvider labelProvider) {
        if (labelProvider == null) throw new IllegalArgumentException("labelProvider cannot be null.");
        setChosenLabelProvider(labelProvider);
        setAvailableLabelProvider(labelProvider);
    }

    /**
     * Set the filter of the available <code>TableViewer</code>.  Only the entries that comply to the filter will
     * be displayed in the available <code>TableViewer</code>.
     * 
     * @param filter <code>ViewerFilter</code>
     */
    public void setAvailableViewerFilter(ViewerFilter filter) {
        if (isEqual(this.availableViewerFilter, filter))return;
        final ViewerFilter[] filters = availableViewer.getFilters();
        for (int i = 0; i < filters.length; i++) {
            availableViewer.removeFilter(filters[i]);
        }
        availableViewer.addFilter(filter);
    }
    
    /**
     * Set the filter of the chosen <code>TableViewer</code>.  Only the entries that comply to the filter will
     * be displayed in the chosen <code>TableViewer</code>.
     * 
     * @param filter <code>ViewerFilter</code>
     */
    public void setChosenViewerFilter(ViewerFilter filter) {
        if (isEqual(this.chosenViewerFilter, filter)) return;
        final ViewerFilter[] filters = chosenViewer.getFilters();
        for (int i = 0; i < filters.length; i++) {
            chosenViewer.removeFilter(filters[i]);
        }
        chosenViewer.addFilter(filter);
    }
    
    /**
     * Retrieve the available table
     * 
     * @return <code>Table</code>
     */
    public Table getAvailableTable() {
        return this.availableTable;
    }
    
    /**
     * Retrieve the chosen table
     * 
     * @return <code>Table</code>
     */
    public Table getChosenTable() {
        return this.chosenTable;
    }
    
    /**
     * Marks the available table's lines as visible if the argument is <code>true</code>,
     * and marks it invisible otherwise.
     *  
     * @param show <code>boolean</code>
     */
    public void setAvailableTableLinesVisible(boolean show) {
        getAvailableTable().setLinesVisible(show);
    }
    
    /**
     * Marks the chosen table's lines as visible if the argument is <code>true</code>,
     * and marks it invisible otherwise.
     *  
     * @param show <code>boolean</code>
     */
    public void setChosenTableLinesVisible(boolean show) {
        getChosenTable().setLinesVisible(show);
    }
    
    /**
     * Marks the available table's header as visible if the argument is <code>true</code>,
     * and marks it invisible otherwise.
     *  
     * @param show <code>boolean</code>
     */
    public void setAvailableTableHeaderVisible(boolean show) {
        getAvailableTable().setHeaderVisible(show);
    }
    
    /**
     * Marks the chosen table's header as visible if the argument is <code>true</code>,
     * and marks it invisible otherwise.
     *  
     * @param show <code>boolean</code>
     */
    public void setChosenTableHeaderVisible(boolean show) {
        getChosenTable().setHeaderVisible(show);
    }
    
    /**
     * Mark both tables' lines as visible if the argument is <code>true</code>,
     * and marks it invisible otherwise.
     *  
     * @param show <code>boolean</code>
     */
    public void setTableLinesVisible(boolean show) {
        setAvailableTableLinesVisible(show);
        setChosenTableLinesVisible(show);
    }
    
    /**
     * Marks both tables' headers as visible if the argument is <code>true</code>,
     * and marks it invisible otherwise.
     *  
     * @param show <code>boolean</code>
     */
    public void setTableHeadersVisible(boolean show) {
        setAvailableTableHeaderVisible(show);
        setChosenTableHeaderVisible(show);
    }
    
    /**
     * Add a <code>ListContentChangedListener</code> to the chosen list.  The listener will be notified when 
     * the content of the chosen list have changed.
     * 
     * @param listener <code>ListContentChangedListener</code>
     */
    public void addChosenListChangedSelectionListener(ListContentChangedListener<T> listener) {
        if (listener != null)
            chosenListChangedListeners.add(listener);
    }
    
    /**
     * Remove the <code>ListContentChangedListener</code> from the chosen list.
     * 
     * @param listener <code>ListContentChangedListener</code>
     */
    public void removeChosenListChangedSelectionListener(ListContentChangedListener<T> listener) {
        if (listener != null)
            chosenListChangedListeners.remove(listener);
    }
    
    /**
     * Add a <code>ListContentChangedListener</code> to the available list.  The listener will be notified when 
     * the content of the available list have changed.
     * 
     * @param listener <code>ListContentChangedListener</code>
     */
    public void addAvailableListChangedSelectionListener(ListContentChangedListener<T> listener) {
        if (listener != null)
            availableListChangedListeners.add(listener);
    }
    
    /**
     * Remove the <code>ListContentChangedListener</code> from the available list.
     * 
     * @param listener <code>ListContentChangedListener</code>
     */
    public void removeAvailableListChangedSelectionListener(ListContentChangedListener<T> listener) {
        if (listener != null)
            availableListChangedListeners.remove(listener);
    }
    
    private void fireChosenListContentChangedEvent(final IRemovableContentProvider<T> contentProvider) {
        final Iterator<ListContentChangedListener<T>> it = chosenListChangedListeners.iterator();
        while (it.hasNext()) {
            (it.next()).listContentChanged(contentProvider);
        }
    }
    
    private void fireAvailableListContentChangedEvent(final IRemovableContentProvider<T> contentProvider) {
        final Iterator<ListContentChangedListener<T>> it = availableListChangedListeners.iterator();
        while (it.hasNext()) {
            (it.next()).listContentChanged(contentProvider);
        }
    }
    
    /**
     * A listener that can be added to a list to be notified when the content have changed. 
     * 
     * @author Carien van Zyl
     */
    public interface ListContentChangedListener<E extends Object> {
        /**
         * Method that is called every time the content of the <code>TableViewer</code> has changed.
         * @param contentProvider <code>IRemovableContentProvider</code>  of the <code>TableViewer</code>.  <code>getElements</code> can be called
         * on the contentProvider to retrieve the new items.
         */
        void listContentChanged(final IRemovableContentProvider<E> contentProvider);
    }
    
    /**
     * Helper method to test equality.  This method make provision for <code>null</code>s.
     *  
     * @param obj1 <code>Object</code>
     * @param obj2 <code>Object</code>
     * @return <code>boolean</code> indicating equality.  If both objects are <code>null</code>, <code>true</code> will be returned. 
     */
    @SuppressWarnings("null")
    public static boolean isEqual(Object obj1, Object obj2) {
        if ((obj1 == null) ^ (obj2 == null)) return false;
        if ((obj1 == null) && (obj2 == null)) return true;
        return obj1.equals(obj2);
    }
    
}
