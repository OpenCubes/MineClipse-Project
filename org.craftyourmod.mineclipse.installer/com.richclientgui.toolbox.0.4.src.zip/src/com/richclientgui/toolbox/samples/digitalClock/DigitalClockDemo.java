package com.richclientgui.toolbox.samples.digitalClock;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;

import com.richclientgui.toolbox.clock.DigitalClock;
import com.richclientgui.toolbox.clock.DigitalClock.CLOCK_STYLE;
import com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry;

public class DigitalClockDemo {
	
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = getShell(display);
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
	
	public static Shell getShell(Display display){
		final Shell shell = new Shell(display);
		shell.setText("Digital Clock Demo");
		shell.setLayout(new GridLayout());
		new DigitalClockDemo(shell);
		shell.open();
		shell.pack();
		return shell;
	}
	
	public DigitalClockDemo(Shell shell){		
		final Composite composite = new Composite(shell,SWT.NONE);
		composite.setLayout(new GridLayout(3,false));
		composite.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		
		createGroup(composite,CLOCK_STYLE.COUNTER,false);
		
		createGroup(composite,CLOCK_STYLE.CLOCK_12_HOURS,true);
		
		createGroup(composite,CLOCK_STYLE.CLOCK_24_HOURS,true);
	}
	
	private void createGroup(final  Composite parent,final CLOCK_STYLE style, boolean customCursor){		
		final Group groupCounter = new Group(parent,SWT.NONE);
		groupCounter.setLayout(new GridLayout(3,false));
		groupCounter.setText(style.toString());
		final DigitalClock clockCounter = customCursor?
				new DigitalClock(groupCounter,SWT.BORDER,style,new Cursor(Display.getDefault(),
						SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.CURSOR_UP).getImageData(),4,0),
						new Cursor(Display.getDefault(),SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.CURSOR_DOWN).getImageData(),4,8)):
				new DigitalClock(groupCounter,SWT.BORDER,style);		
		final GridData gd = new GridData(SWT.CENTER,SWT.BEGINNING,false,false);
		gd.horizontalSpan = 3;
		clockCounter.setLayoutData(gd);
			
		final Label sep = new Label(groupCounter,SWT.HORIZONTAL|SWT.SEPARATOR);		
		final GridData gdSep = new GridData(SWT.FILL,SWT.BEGINNING,true,false);
		gdSep.horizontalSpan = 3;
		sep.setLayoutData(gdSep);
		
		final Button start = new Button(groupCounter,SWT.PUSH);
		start.setText("start");
		start.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				clockCounter.start();
			}
		});
		
		final Button stop = new Button(groupCounter,SWT.PUSH);
		stop.setText("stop");
		stop.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				clockCounter.stop();
			}
		});
		
		final Button reset = new Button(groupCounter,SWT.PUSH);
		reset.setText("reset");
		reset.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(style.equals(CLOCK_STYLE.COUNTER)){
					clockCounter.reset();	
				}else{
					clockCounter.resetToCurrentTime();
				}				
			}
		});
		
		if(style.equals(CLOCK_STYLE.COUNTER)){
			clockCounter.start();
		}
		
		final Label sep2 = new Label(groupCounter,SWT.HORIZONTAL|SWT.SEPARATOR);		
		sep2.setLayoutData(gdSep);
		
		final GridData gdRO = new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false);
		gdRO.horizontalSpan = 1;
		final Button readOnly = new Button(groupCounter,SWT.CHECK);
		readOnly.setText("Read Only");
		readOnly.setLayoutData(gdRO);
		readOnly.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				clockCounter.setEnabled(!readOnly.getSelection());
			}
		});
		
		new Label(groupCounter,SWT.NONE).setText("Font size:");
		final Spinner fontSize = new Spinner(groupCounter,SWT.READ_ONLY|SWT.BORDER);		
		fontSize.setDigits(0);
		fontSize.setMaximum(20);			
		fontSize.setSelection(Display.getDefault().getSystemFont().getFontData()[0].getHeight());
		fontSize.setMinimum(5);
		fontSize.setIncrement(1);
		fontSize.addModifyListener(new ModifyListener(){
			public void modifyText(ModifyEvent arg0) {
				final Font fnt = Display.getDefault().getSystemFont();								
				clockCounter.setFont(new Font(Display.getDefault(),new FontData(fnt.getFontData()[0].getName(),
						fontSize.getSelection(),
						fnt.getFontData()[0].getStyle())));	
				groupCounter.layout();
				parent.layout();
			}
 		});
		final GridData gdFontSize = new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false);
		gdFontSize.horizontalSpan = 1;
		fontSize.setLayoutData(gdFontSize);
		
		final Label sep3 = new Label(groupCounter,SWT.HORIZONTAL|SWT.SEPARATOR);		
		sep3.setLayoutData(gdSep);
		
		new Label(groupCounter,SWT.NONE).setText("Background Colour:");
		
		final ColorDialog colorDialog = new ColorDialog(parent.getShell(),SWT.NONE);
		colorDialog.setText("Choose a Colour ");
		
		final Button chooseBackground = new Button(groupCounter,SWT.PUSH);
		chooseBackground.setText("Change");
		chooseBackground.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				final RGB rgb = colorDialog.open();
				if(rgb != null){
					clockCounter.setBackground(new Color(Display.getDefault(),rgb));
				}
			}
		});
		
		final GridData gdchooseBackground = new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false);
		gdchooseBackground.horizontalSpan = 2;
		chooseBackground.setLayoutData(gdchooseBackground);
		
		
		new Label(groupCounter,SWT.NONE).setText("Foreground Colour:");
		final Button foreground = new Button(groupCounter,SWT.PUSH);
		foreground.setText("Change");
		foreground.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				final RGB rgb = colorDialog.open();
				if(rgb != null){
					clockCounter.setForeground(new Color(Display.getDefault(),rgb));
				}
			}
		});
	
		foreground.setLayoutData(gdchooseBackground);			
		
		new Label(groupCounter,SWT.NONE).setText("Highlight Colour:");
		final Button highlight = new Button(groupCounter,SWT.PUSH);
		highlight.setText("Change");
		highlight.setToolTipText("This colour is shown when incrementing the clock");
		highlight.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				final RGB rgb = colorDialog.open();
				if(rgb != null){
					clockCounter.setHighLightColor(new Color(Display.getDefault(),rgb));
				}
			}
		});
		highlight.setLayoutData(gdchooseBackground);
	}
}
