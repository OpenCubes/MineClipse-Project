/*
 * Created on 19 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

/**
 * @author Carien van Zyl
 */
public enum Team {
    
    CapeCobras("Nashua Cape Cobras"),
    Titans("Nashua Titans"),
    Warriors("Warriors"),
    Eagles("Gestetner Diamond Eagles"),
    Dolphins("Nashua Dolphins");
    
    private final String name;
    
    private Team(String name) {
        this.name = name;
    }
    
    public int getID() {
        return ordinal();
    }
    
    public String getName() {
        return this.name;
    }
    
    @Override
    public String toString() {
        return name;
    }
    
    
}
