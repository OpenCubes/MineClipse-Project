/*
 * Created on 19 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Carien van Zyl
 */
public class CricketerConstants {

    final static List<Cricketer> saCricketers = new ArrayList<Cricketer>(20);
    static {
        saCricketers.add(new Cricketer("Graeme", "Smith", Team.CapeCobras));
        saCricketers.add(new Cricketer("AB", "de Villiers", Team.Titans));
        saCricketers.add(new Cricketer("Herschelle", "Gibbs", Team.CapeCobras));
        saCricketers.add(new Cricketer("Justin", "Kemp", Team.CapeCobras));
        saCricketers.add(new Cricketer("Mark", "Boucher", Team.Warriors));
        saCricketers.add(new Cricketer("Shaun", "Pollock", Team.Dolphins));
        saCricketers.add(new Cricketer("Albie", "Morkel", Team.Titans));
        saCricketers.add(new Cricketer("Vernon", "Philander", Team.CapeCobras));
        saCricketers.add(new Cricketer("Johan", "van der Wath", Team.Eagles));
        saCricketers.add(new Cricketer("Andre", "Nel", Team.Titans));
        saCricketers.add(new Cricketer("Makhaya", "Ntini", Team.Warriors));
        saCricketers.add(new Cricketer("Gulam", "Bodi", Team.Titans));
        saCricketers.add(new Cricketer("JP", "Duminy", Team.CapeCobras));
        saCricketers.add(new Cricketer("Morne", "Morkel", Team.Titans));
        saCricketers.add(new Cricketer("Thandi", "Tshabalala", Team.Eagles));
    }
    
    public static final int COL_NAME = 0;
    public static final int COL_SURNAME = 1;
    public static final int COL_TEAM = 2;
}
