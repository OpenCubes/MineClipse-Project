/*
 * Created on 19 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

/**
 * @author Carien van Zyl
 */
public class CricketerViewerFilter extends ViewerFilter {

    private Team filterTeam = null;
    
    @Override
    public boolean select(Viewer viewer, Object parentElement, Object element) {
        if (!(element instanceof Cricketer)) return false;
        if (filterTeam == null) return true;
        return filterTeam.equals(((Cricketer) element).getTeam());
    }
    
    public void setFilterTeam(Team team) {
        this.filterTeam = team;
    }

}
