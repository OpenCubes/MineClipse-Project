/*
 * Created on 19 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;

/**
 * @author Carien van Zyl
 */
public class CricketerComparator extends ViewerComparator {

    private int sortColumn = -1;
    private boolean sortAsc = true; 
    
    @Override
    public int compare(Viewer viewer, Object e1, Object e2) {
        if ((e1 == null) && (e2 == null)) return 0;
        int result = 0;
        if ((e2 == null) || !(e2 instanceof Cricketer)) {
            result = -1;
        } else if ((e1 == null) || !(e1 instanceof Cricketer)) {
            result = 1;
        } else {
            final Cricketer cricketer1 = (Cricketer) e1;
            final Cricketer cricketer2 = (Cricketer) e2;

            switch (sortColumn) {
            case CricketerConstants.COL_NAME : 
                result = compareStrings(cricketer1.getName(),cricketer2.getName());
                break;
            case CricketerConstants.COL_SURNAME : 
                result = compareStrings(cricketer1.getSurname(), cricketer2.getSurname());
                break;
            case CricketerConstants.COL_TEAM : 
                result = compareStrings(cricketer1.getTeam().getName(), cricketer2.getTeam().getName());
                break;
            default : result = 0;
            }
        }
        return sortAsc ? result : result * (-1); 
    }
    
    @Override
    public boolean isSorterProperty(Object element, String property) {
        return true;
    }
    
    /**
     * Set the sorting column.  The sort order will be returned.
     * 
     * @param index <code>int</code> index of column to be sorted.
     * @return <code>boolean</code> sort order.
     */
    public boolean setSortColumn(int index) {
        if (index == this.sortColumn) {
            sortAsc = !sortAsc;
        } else {
            sortAsc = true;
        }
        this.sortColumn = index;
        return sortAsc;
    }
    
    private int compareStrings(String s1, String s2) {
        if ((s1 == null) && (s2 == null)) return 0;
        if (s1 == null) return 1;
        if (s2 == null) return -1;
        return s1.compareTo(s2);
    }
}
