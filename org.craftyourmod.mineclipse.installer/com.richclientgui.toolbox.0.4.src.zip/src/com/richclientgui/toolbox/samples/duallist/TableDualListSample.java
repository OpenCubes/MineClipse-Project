/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableColumn;

import com.richclientgui.toolbox.duallists.CustomTableDualListComposite;
import com.richclientgui.toolbox.duallists.IRemovableContentProvider;
import com.richclientgui.toolbox.duallists.RemovableContentProvider;
import com.richclientgui.toolbox.duallists.TableColumnData;
import com.richclientgui.toolbox.duallists.DualListComposite.ListContentChangedListener;

/**
 * @author Carien van Zyl
 */
public class TableDualListSample {
    
    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("Custom Table Dual List Sample");
        
        shell.setLayout(new GridLayout());
        
        //set up the filter composite
        final Composite filterComposite = new Composite(shell, SWT.NONE);
        filterComposite.setLayout(new GridLayout(2, false));
        filterComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        new Label(filterComposite, SWT.NONE).setText("Team Filter:");
        final EnumComboDelegate<Team> cmbTeam = new EnumComboDelegate<Team>(filterComposite, SWT.BORDER | SWT.READ_ONLY);
        cmbTeam.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        cmbTeam.setEnumItems(Team.values(), true);
        cmbTeam.setInitialObject("<No Filter>");
        
        //set up the duallist
        //columns of available table
        final TableColumnData[] columnData = new TableColumnData[] { 
                new TableColumnData(CricketerConstants.COL_NAME, "Name", 80),
                new TableColumnData(CricketerConstants.COL_SURNAME, "Surname", 90),
                new TableColumnData(CricketerConstants.COL_TEAM, "Team", 140)
            };
        //create custom dual list
        final CustomTableDualListComposite<Cricketer> dualTableViewer = 
            new CustomTableDualListComposite<Cricketer>(shell, SWT.NONE, columnData, null);
        //set the labels
        dualTableViewer.setViewerLabels("Available:", "Chosen:");
        //set properties of the chosen table
        dualTableViewer.setChosenTableLinesVisible(false);
        dualTableViewer.setChosenTableHeaderVisible(false);
        //create a filter for the available table
        final CricketerViewerFilter viewerFilter = new CricketerViewerFilter();
        dualTableViewer.setAvailableViewerFilter(viewerFilter);
        //set the comparators
        final CricketerComparator viewerComparator = new CricketerComparator();
        dualTableViewer.setAvailableViewerComparator(viewerComparator);
        dualTableViewer.setChosenComparator(new ViewerComparator());
        //add listener on available table columns to indicate sorting.
        final TableColumn[] columns = dualTableViewer.getAvailableTable().getColumns();
        for (int i = 0; i < columns.length; i++) {
            final TableColumn currColumn = columns[i];
            final int currIndex = i;
            currColumn.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent e) {
                    final boolean sortOrder = viewerComparator.setSortColumn(currIndex);
                    dualTableViewer.getAvailableTable().setSortColumn(currColumn);
                    dualTableViewer.getAvailableTable().setSortDirection(sortOrder ? SWT.DOWN : SWT.UP);
                    dualTableViewer.refreshAvailableViewer();
                }
            });
        }
        //set the available label provider
        dualTableViewer.setAvailableLabelProvider(new CricketerLabelProvider());
        //set the content providers
        dualTableViewer.setAvailableContentProvider(new RemovableContentProvider<Cricketer>(CricketerConstants.saCricketers));
        dualTableViewer.setChosenContentProvider(new RemovableContentProvider<Cricketer>());
        
        cmbTeam.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                viewerFilter.setFilterTeam(cmbTeam.getSelectedEnum());
                dualTableViewer.refreshAvailableViewer();
            }
        });
        
        //Example to show how other components can be notified of changes in the chosen list.
        final Label lblContent = new Label(shell, SWT.NONE);
        lblContent.setText("Number of cricketers selected: ");
        lblContent.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        dualTableViewer.addChosenListChangedSelectionListener(new ListContentChangedListener<Cricketer>() {
            public void listContentChanged(IRemovableContentProvider<Cricketer> contentProvider) {
                lblContent.setText("Number of cricketers selected: " + contentProvider.getNumberOfElements());
            }
        });
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        
    }
}
