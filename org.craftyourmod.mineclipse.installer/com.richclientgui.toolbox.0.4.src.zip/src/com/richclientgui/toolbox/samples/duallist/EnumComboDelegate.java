/*
 * Created on 19 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.events.MouseWheelListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;

import com.richclientgui.toolbox.propagate.PropagateComposite;

/**
 * @author Carien van Zyl
 */
public class EnumComboDelegate<K extends Enum<K>> extends PropagateComposite {

    private final Combo combo;
    private Map<Integer, K> indexEnumMap = new HashMap<Integer, K>();
    private K[] enums;
    private Object initialObject;
    
    public EnumComboDelegate(Composite parent, int style) {
        super(parent, SWT.NONE);
        final GridLayout layout = new GridLayout();
        layout.marginWidth = 0;
        layout.marginHeight = 0;
        this.setLayout(layout);
        combo = new Combo(this, style);
        combo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
    }
    
    public void setEnumItems(final K[] enumItems) {
        setEnumItems(enumItems, false);
    }
    
    public void setInitialObject(Object obj) {
        if ((obj == null) && (initialObject != null)) {
            combo.remove(0);
        } else if ((initialObject == null) && (obj != null)) {
            combo.add(obj.toString(), 0);
        } else if ((initialObject != null) && (obj != null)) {
            combo.setItem(0, obj.toString());
        }
        initialObject = obj;
    }
    
    public void setEnumItems(final K[] enumItems, boolean sort) {
        if (enumItems == null) return;
        if (sort) {
            Arrays.sort(enumItems, new Comparator<K>() {
                public int compare(K o1,K o2) {
                    final String stringO1 = getEnumString(o1);
                    final String stringO2 = getEnumString(o2);
                    if ((stringO1 == null) && (stringO2 == null)) return 0;
                    if (stringO1 == null) return -1;
                    if (stringO2 == null) return 1;
                    return stringO1.compareTo(stringO2);
                }
            });
        }
        indexEnumMap.clear();
        
        final int offset = (initialObject == null) ? 0 : 1;
        final String[] items = new String[enumItems.length + offset];
        if (initialObject != null) {
            items[0] = initialObject.toString();
        }
        for (int i = offset; i < enumItems.length; i++) {
            items[i] = getEnumString(enumItems[i]);
            indexEnumMap.put(new Integer(i), enumItems[i]);
        }
        combo.setItems(items);
        enums = enumItems;
    }
    
    public K getSelectedEnum() {
        int selectedIndex = combo.getSelectionIndex();
        if (selectedIndex < 0) return null;
        if (initialObject != null) {
            if (selectedIndex == 0) return null;
            selectedIndex--;
        }
        return indexEnumMap.get(new Integer(selectedIndex));
    }
    
    public K getEnum(int index) {
        if ((index == 0) && (initialObject != null)) return null; 
        return indexEnumMap.get(new Integer(index));
    }
    
    public K[] getEnums() {
        return enums;
    }
    
    
    //TODO addEnum(Enum<K> enumItem, int index); - add enum at index
    //TODO addEnum(Enum<K> enumItem); - add enum at end of list
    //TODO addEnum(Enum<K> enumItem, boolean sorted) - add enum at sorted location
    //TODO setEnum(Enum<K> enumItem, int index); - replace enum at index
    //TODO remove(K enumItem)
    //TODO selectEnum
    
    /**
     * Subclasses can override to implement a custom way of displaying the enums as strings.  By default value.toString() is used.
     * @param value
     * @return
     */
    public String getEnumString(K value) {
        if (value == null) return "";
        return value.toString();
    }
    
    //Delegate methods
    @Override
    public void setBackground(Color color) {
        combo.setBackground(color);
    }
    
    @Override
    public void setBackgroundImage(Image image) {
        combo.setBackgroundImage(image);
    }
    
    @Override
    public void setBackgroundMode(int mode) {
        combo.setBackgroundMode(mode);
    }
    
    @Override
    public boolean setFocus() {
        return combo.setFocus();
    }
    
    @Override
    public void setFont(Font font) {
        combo.setFont(font);
    }
    
    @Override
    public void setForeground(Color color) {
        combo.setForeground(color);
    }
    
    public void setText(String string) {
        combo.setText(string);
    }
    
    public void setTextLimit(int limit) {
        combo.setTextLimit(limit);
    }
    
    @Override
    public void setToolTipText(String string) {
        combo.setToolTipText(string);
    }
    
    @Override
    public Color getBackground() {
        return combo.getBackground();
    }
    
    @Override
    public Image getBackgroundImage() {
        return combo.getBackgroundImage();
    }
    
    @Override
    public int getBackgroundMode() {
        return combo.getBackgroundMode();
    }
    
    @Override
    public Font getFont() {
        return combo.getFont();
    }
    
    @Override
    public Color getForeground() {
        return combo.getForeground();
    }
    
    public String getText() {
        return combo.getText();
    }
    
    public int getTextLimit() {
        return combo.getTextLimit();
    }
    
    public String getTooltipText() {
        return combo.getToolTipText();
    }
    
    @Override
    public int getStyle() {
        return combo.getStyle();
    }
    
    public int getSelectionIndex() {
        return combo.getSelectionIndex();
    }
    
    public void addSelectionListener(SelectionListener listener) {
        combo.addSelectionListener(listener);
    }
    
    @Override
    public void addMouseListener(MouseListener listener) {
        combo.addMouseListener(listener);
    }
    
    @Override
    public void addMouseTrackListener(MouseTrackListener listener) {
        combo.addMouseTrackListener(listener);
    }
    
    @Override
    public void addMouseMoveListener(MouseMoveListener listener) {
        combo.addMouseMoveListener(listener);
    }
    
    @Override
    public void addMouseWheelListener(MouseWheelListener listener) {
        combo.addMouseWheelListener(listener);
    }
}
