/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.duallists.StringDualListComposite;

/**
 * @author Carien van Zyl
 */
public class StringDualListSample {
    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("String Dual List Sample");
        
        shell.setLayout(new GridLayout());
        
        final List<String> initialList = new ArrayList<String>(20);
        initialList.add("Graeme Smith");
        initialList.add("AB de Villiers");
        initialList.add("Herschelle Gibbs");
        initialList.add("Justin Kemp");
        initialList.add("Mark Boucher");
        initialList.add("Shaun Pollock");
        initialList.add("Albie Morkel");
        initialList.add("Vernon Philander");
        initialList.add("Johan van der Wath");
        initialList.add("Andre Nel");
        initialList.add("Makhaya Ntini");
        initialList.add("Gulam Bodi");
        initialList.add("JP Duminy");
        initialList.add("Morne Morkel");
        initialList.add("Thandi Tshabalala");
        
        //create the string dual list with a given list of entries
        new StringDualListComposite(shell, SWT.NONE, initialList, null);
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        
    }
}
