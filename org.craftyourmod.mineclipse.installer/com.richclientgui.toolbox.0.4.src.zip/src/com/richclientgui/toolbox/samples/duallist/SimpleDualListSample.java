/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.duallists.DualListComposite;
import com.richclientgui.toolbox.duallists.RemovableContentProvider;

/**
 * @author Carien van Zyl
 */
public class SimpleDualListSample {
    
    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("Simple Dual List Sample");
        
        shell.setLayout(new GridLayout());
        
        //Create the dual list.
        final DualListComposite<Cricketer> dualList = new DualListComposite<Cricketer>(shell, SWT.NONE);
        //set the contentproviders
        dualList.setAvailableContentProvider(new RemovableContentProvider<Cricketer>(CricketerConstants.saCricketers));
        dualList.setChosenContentProvider(new RemovableContentProvider<Cricketer>());
        //set comparators
        dualList.setComparators(new ViewerComparator());
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        
    }
    
   
}
