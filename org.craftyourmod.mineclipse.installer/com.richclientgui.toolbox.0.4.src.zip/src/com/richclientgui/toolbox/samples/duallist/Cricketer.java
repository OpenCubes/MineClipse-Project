/*
 * Created on 17 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.duallist;

/**
 * @author Carien van Zyl
 */
public class Cricketer {
    
    private String name;
    private String surname;
    private Team team;
    
    public Cricketer(String name, String surname, Team team) {
        this.name = name;
        this.surname = surname;
        this.team = team;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getSurname() {
        return this.surname;
    }
    
    public Team getTeam() {
        return this.team;
    }
    
    @Override
    public String toString() {
        return name + " " + surname;
    }
    
}
