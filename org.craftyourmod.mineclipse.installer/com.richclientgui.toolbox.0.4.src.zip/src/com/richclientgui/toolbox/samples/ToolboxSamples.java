package com.richclientgui.toolbox.samples;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.samples.button.CoolButtonDemo;
import com.richclientgui.toolbox.samples.digitalClock.DigitalClockDemo;
import com.richclientgui.toolbox.samples.gauges.CoolGaugeDemo;
import com.richclientgui.toolbox.samples.googlemap.GoogleMapDemo;
import com.richclientgui.toolbox.samples.label.ScrollingLabelDemo;
import com.richclientgui.toolbox.samples.progressIndicator.CoolProgressBarDemo;
import com.richclientgui.toolbox.samples.progressIndicator.ImageSequencerDemo;
import com.richclientgui.toolbox.samples.slider.CoolSliderDemo;

public class ToolboxSamples {
	private static final Map<String,Shell> demoShown = new HashMap<String,Shell>();
	private static boolean globalRemove = false;
	
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("RCP Toolbox Demos");
		shell.setLayout(new GridLayout());
		final Composite composite = new Composite(shell,SWT.NONE);
		composite.setLayout(new GridLayout(4,true));
		composite.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		
		//--------------------- DEMOS -----------------------------
		final Button coolButtons = new Button(composite,SWT.PUSH);
		coolButtons.setText("Cool Button");
		coolButtons.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		coolButtons.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(CoolButtonDemo.class.getCanonicalName())){					
					final Shell shl = CoolButtonDemo.getShell(Display.getDefault());
					demoShown.put(CoolButtonDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(CoolButtonDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		
		final Button coolSliders = new Button(composite,SWT.PUSH);
		coolSliders.setText("Cool Slider");
		coolSliders.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));		
		coolSliders.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(CoolSliderDemo.class.getCanonicalName())){					
					final Shell shl = CoolSliderDemo.getShell(Display.getDefault());
					demoShown.put(CoolSliderDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
							demoShown.remove(CoolSliderDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		
		final Button imageSequence = new Button(composite,SWT.PUSH);
		imageSequence.setText("Image Sequencer");
		imageSequence.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		imageSequence.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(ImageSequencerDemo.class.getCanonicalName())){					
					final Shell shl = ImageSequencerDemo.getShell(Display.getDefault());
					demoShown.put(ImageSequencerDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(ImageSequencerDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		
		final Button coolGauges = new Button(composite,SWT.PUSH);
		coolGauges.setText("Cool Gauge");
		coolGauges.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		coolGauges.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(CoolGaugeDemo.class.getCanonicalName())){					
					final Shell shl = CoolGaugeDemo.getShell(Display.getDefault());
					demoShown.put(CoolGaugeDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(CoolGaugeDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		final Button scrollingText = new Button(composite,SWT.PUSH);
		scrollingText.setText("Scrolling Text");
		scrollingText.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		scrollingText.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(ScrollingLabelDemo.class.getCanonicalName())){					
					final Shell shl = ScrollingLabelDemo.getShell(Display.getDefault());
					demoShown.put(ScrollingLabelDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(ScrollingLabelDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		
		final Button digitalClock = new Button(composite,SWT.PUSH);
		digitalClock.setText("Digital Clock");
		digitalClock.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		digitalClock.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(DigitalClockDemo.class.getCanonicalName())){					
					final Shell shl = DigitalClockDemo.getShell(Display.getDefault());
					demoShown.put(DigitalClockDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(DigitalClockDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		final Button googleMap = new Button(composite,SWT.PUSH);
		googleMap.setText("Google Map");
		googleMap.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		googleMap.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {			
				if(!demoShown.containsKey(GoogleMapDemo.class.getCanonicalName())){					
					final Shell shl = GoogleMapDemo.getShell(Display.getDefault());
					demoShown.put(GoogleMapDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(GoogleMapDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
		final Button coolProgressBar = new Button(composite,SWT.PUSH);
		coolProgressBar.setText("Cool Progress Bar");
		coolProgressBar.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
		coolProgressBar.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!demoShown.containsKey(CoolProgressBarDemo.class.getCanonicalName())){					
					final Shell shl = CoolProgressBarDemo.getShell(Display.getDefault());
					demoShown.put(CoolProgressBarDemo.class.getCanonicalName(),shl);
					shl.addDisposeListener(new DisposeListener(){
						public void widgetDisposed(DisposeEvent arg0) {
							if(!globalRemove)
								demoShown.remove(CoolProgressBarDemo.class.getCanonicalName());
						}						
					});
				}
			}
		});
//TODO: ADD LATER		
//		final Button dualLists = new Button(composite,SWT.PUSH);
//		dualLists.setText("Dual List");
//		dualLists.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
//		dualLists.addSelectionListener(new SelectionAdapter(){
//			@Override
//			public void widgetSelected(SelectionEvent e) {
//				
//			}
//		});
//		final Button propagate = new Button(composite,SWT.PUSH);
//		propagate.setText("Progagate Composites");
//		propagate.setLayoutData(new GridData(SWT.FILL,SWT.FILL,false,false));
//		propagate.addSelectionListener(new SelectionAdapter(){
//			@Override
//			public void widgetSelected(SelectionEvent e) {
//				
//			}
//		});
		//--------------------- end --------------------------------
		
		shell.open();
		shell.pack();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		globalRemove = true;
		final Iterator<Shell> iter = demoShown.values().iterator();
		while(iter.hasNext()){
			iter.next().dispose();
		}
	}
}
