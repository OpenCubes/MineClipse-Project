/*
 * Created on 19 Oct 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.propagate;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.richclientgui.toolbox.propagate.PropagateComposite;

/**
 * @author Carien van Zyl
 */
public class PropagateFontSample {

    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("Propagate Font Sample");
        
        shell.setLayout(new GridLayout(4, false));
        
        final Font arial = new Font(Display.getDefault(),"arial",8,SWT.BOLD);
        final Font courier = new Font(Display.getDefault(),"courier",8,SWT.NONE);
        
        final PropagateComposite mainComposite = new PropagateComposite(shell, SWT.BORDER);
        mainComposite.setLayout(new GridLayout());
        final GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        gd.horizontalSpan = 4;
        mainComposite.setLayoutData(gd);
        final Label lblMain = new Label(mainComposite, SWT.NONE);
        lblMain.setText("Main Composite");
        lblMain.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtOne = new Text(mainComposite, SWT.BORDER);
        txtOne.setText("Default 'Text' on Main");
        txtOne.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtTwo = new Text(mainComposite, SWT.BORDER);
        txtTwo.setText("Set to  be excluded from propagate font on Main");
        txtTwo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        mainComposite.excludeFromPropagateFont(txtTwo);
        
        final PropagateComposite composite1 = new PropagateComposite(mainComposite, SWT.BORDER);
        composite1.setLayout(new GridLayout());
        composite1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        final Label lblComposite1 = new Label(composite1, SWT.NONE);
        lblComposite1.setText("Composite 1 - set to propagate font");
        lblComposite1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtInclude = new Text(composite1, SWT.BORDER);
        txtInclude.setText("Default 'Text' on Composite 1");
        txtInclude.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtExclude = new Text(composite1, SWT.BORDER);
        txtExclude.setText("Set to  be excluded from propagate font on Composite 1");
        txtExclude.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        composite1.excludeFromPropagateFont(txtExclude);
        
        final PropagateComposite composite2 = new PropagateComposite(mainComposite, SWT.BORDER);
        composite2.setLayout(new GridLayout());
        composite2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        mainComposite.excludeFromPropagateFont(composite2);
        final Label lblComposite2 = new Label(composite2, SWT.NONE);
        lblComposite2.setText("Composite 2");
        lblComposite2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtIllustrate = new Text(composite2, SWT.BORDER);
        txtIllustrate.setText("Default 'Text' on Composite 2");
        txtIllustrate.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnArial = new Button(shell, SWT.PUSH);
        btnArial.setText("Arial");
        btnArial.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                mainComposite.setFont(arial);        
            } 
        });
        btnArial.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnCourier = new Button(shell, SWT.PUSH);
        btnCourier.setText("Courier");
        btnCourier.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                mainComposite.setFont(courier);   
            } 
        });
        btnCourier.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnToggle = new Button(shell, SWT.TOGGLE);
        btnToggle.setText("Propagate Font");
        btnToggle.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                mainComposite.setPropagateFont(btnToggle.getSelection());
            }
        });
        btnToggle.setSelection(true);
        btnToggle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnToggleComposite2 = new Button(shell, SWT.TOGGLE);
        btnToggleComposite2.setText("Include Composite 2");
        btnToggleComposite2.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                final boolean include = btnToggleComposite2.getSelection();
                if (include) {
                    mainComposite.includePropagateFont(composite2);
                } else {
                    mainComposite.excludeFromPropagateFont(composite2);
                }
            }
        });
        btnToggleComposite2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
    }
}
