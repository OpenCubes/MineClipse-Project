/*
 * Created on 14 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.propagate;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.richclientgui.toolbox.propagate.PropagateComposite;

/**
 * @author Carien van Zyl
 */
public class PropagateCompositeSample {

    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("Propagate Composite Sample");
        
        shell.setLayout(new GridLayout());
        
        //Content Composite
        final PropagateComposite contentComposite = new PropagateComposite(shell, SWT.BORDER);
        contentComposite.setLayout(new GridLayout(3,true));
        contentComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        final Label lblRootComposite = new Label(contentComposite, SWT.NONE);
        lblRootComposite.setText("Content Composite");
        GridData gd = new GridData();
        gd.horizontalSpan = 3;
        lblRootComposite.setLayoutData(gd);
        
        final Button btnEnabled = new Button(contentComposite, SWT.PUSH);
        btnEnabled.setText("Enabled Button");
        btnEnabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnDisabled = new Button(contentComposite, SWT.PUSH);
        btnDisabled.setText("Disabled Button");
        btnDisabled.setEnabled(false);
        btnDisabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnToggle = new Button(contentComposite, SWT.PUSH);
        btnToggle.setText("Toggle Button");
        btnToggle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        
        //Composite 1
        final PropagateComposite pnlOne = new PropagateComposite(contentComposite, SWT.BORDER);
        pnlOne.setLayout(new GridLayout(3, true));
        gd = new GridData(SWT.FILL, SWT.FILL, true, false);
        gd.horizontalSpan = 3;
        pnlOne.setLayoutData(gd);
        
        final Label lblComposite1 = new Label(pnlOne, SWT.NONE);
        lblComposite1.setText("Composite 1");
        lblComposite1.setLayoutData(gd);
        
        final Text txtEnabled = new Text(pnlOne, SWT.BORDER);
        txtEnabled.setText("Enabled Text Field");
        txtEnabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        Text txtDisabled = new Text(pnlOne, SWT.BORDER);
        txtDisabled.setText("Disabled Text Field");
        txtDisabled.setEnabled(false);
        txtDisabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtOne = new Text(pnlOne, SWT.BORDER);
        txtOne.setText("Toggle Text");
        txtOne.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        //Composite 1a
        final PropagateComposite pnlOneA = new PropagateComposite(pnlOne, SWT.BORDER);
        pnlOneA.setLayout(new GridLayout(3, true));
        gd = new GridData(SWT.FILL, SWT.FILL, true, false);
        gd.horizontalSpan = 3;
        pnlOneA.setLayoutData(gd);
        
        final Label lblComposite1a = new Label(pnlOneA, SWT.NONE);
        lblComposite1a.setText("Composite 1a");
        lblComposite1a.setLayoutData(gd);
        
        final Combo cmbEnabled = new Combo(pnlOneA, SWT.BORDER);
        cmbEnabled.setItems(new String[] {"Enabled Combo"});
        cmbEnabled.select(0);
        cmbEnabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Combo cmbDisabled = new Combo(pnlOneA, SWT.BORDER);
        cmbDisabled.setItems(new String[] {"Disabled Combo"});
        cmbDisabled.setEnabled(false);
        cmbDisabled.select(0);
        cmbDisabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Combo cmbToggle = new Combo(pnlOneA, SWT.BORDER);
        cmbToggle.setItems(new String[] {"Toggle Combo"});
        cmbToggle.select(0);
        cmbToggle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
      
        
        //SWT Composite
        final Composite SWTComposite = new Composite(contentComposite, SWT.BORDER);
        SWTComposite.setLayout(new GridLayout(2, true));
        GridData griddata = new GridData(SWT.FILL, SWT.FILL, true, true);
        griddata.horizontalSpan = 3;
        SWTComposite.setLayoutData(griddata);
        
        Label lblDescription = new Label(SWTComposite, SWT.NONE);
        lblDescription.setText("SWT Composite");
        lblDescription.setLayoutData(gd);
        
        final Text txtSWTEnabled = new Text(SWTComposite, SWT.BORDER);
        txtSWTEnabled.setText("Enabled Text");
        txtSWTEnabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtSWTDisabled = new Text(SWTComposite, SWT.BORDER);
        txtSWTDisabled.setText("Disabled Text");
        txtSWTDisabled.setEnabled(false);
        txtSWTDisabled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        Label spacer = new Label(shell, SWT.NONE);
        spacer.setLayoutData(gd);
        
        Label seperator = new Label(shell, SWT.SEPARATOR | SWT.HORIZONTAL);
        seperator.setLayoutData(gd);
        
        //Button Composite
        final Composite buttonComposite = new Composite(shell, SWT.NONE);
        buttonComposite.setLayout(new GridLayout(7, false));
        buttonComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnCompositeRoot = new Button(buttonComposite, SWT.TOGGLE);
        btnCompositeRoot.setText("Content Composite");  
        btnCompositeRoot.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnButton = new Button(buttonComposite, SWT.TOGGLE);
        btnButton.setText("Toggle Button");
        btnButton.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnComposite1 = new Button(buttonComposite, SWT.TOGGLE);
        btnComposite1.setText("Composite 1");   
        btnComposite1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnText1 = new Button(buttonComposite, SWT.TOGGLE);
        btnText1.setText("Toggle Text");
        btnText1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnComposite1a = new Button(buttonComposite, SWT.TOGGLE);
        btnComposite1a.setText("Composite 1a");
        btnComposite1a.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnCombo = new Button(buttonComposite, SWT.TOGGLE);
        btnCombo.setText("Toggle Combo");
        btnCombo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnSWTComposite = new Button(buttonComposite, SWT.TOGGLE);
        btnSWTComposite.setText("SWT Composite");
        btnSWTComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        btnSWTComposite.addSelectionListener(new SelectionAdapter(){
            @Override
            public void widgetSelected(SelectionEvent e) {
                SWTComposite.setEnabled(!btnSWTComposite.getSelection());
            }
        });
        
        btnCompositeRoot.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                contentComposite.setEnabled(!btnCompositeRoot.getSelection());
            }
        });
        
        btnButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                contentComposite.setEnabledOfChild(btnToggle, !btnButton.getSelection());
            }
        });
        
        btnText1.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                pnlOne.setEnabledOfChild(txtOne, !btnText1.getSelection());
            }
        });
        
        btnComposite1.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                contentComposite.setEnabledOfChild(pnlOne, !btnComposite1.getSelection());
            }
        });
        
        btnComposite1a.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                pnlOne.setEnabledOfChild(pnlOneA, !btnComposite1a.getSelection());
            }
        });
        
        btnCombo.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                pnlOneA.setEnabledOfChild(cmbToggle, !btnCombo.getSelection());
            }
        });
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        
    }
}
