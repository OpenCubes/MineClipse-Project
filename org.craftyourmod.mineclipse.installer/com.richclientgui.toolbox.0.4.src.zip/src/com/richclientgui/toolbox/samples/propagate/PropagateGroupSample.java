/*
 * Created on 14 Sep 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.propagate;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.richclientgui.toolbox.propagate.PropagateGroup;

/**
 * @author Carien van Zyl
 */
public class PropagateGroupSample {

    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("Propagate Group Sample");
        
        shell.setLayout(new GridLayout());
        
        //Content Group
        final PropagateGroup contentGroup = new PropagateGroup(shell, SWT.FLAT);
        contentGroup.setLayout(new GridLayout(3,true));
        contentGroup.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        contentGroup.setText("Content Group");
        
        final Button btnEnabled = new Button(contentGroup, SWT.PUSH);
        btnEnabled.setText("Enabled Button");
        
        final Button btnDisabled = new Button(contentGroup, SWT.PUSH);
        btnDisabled.setText("Disabled Button");
        btnDisabled.setEnabled(false);
        
        final Button btnToggle = new Button(contentGroup, SWT.PUSH);
        btnToggle.setText("Toggle Button");
        
        
        //Group 1
        final PropagateGroup groupOne = new PropagateGroup(contentGroup, SWT.FLAT);
        groupOne.setLayout(new GridLayout(3, true));
        GridData gd = new GridData(SWT.FILL, SWT.FILL, true, false);
        gd.horizontalSpan = 3;
        groupOne.setLayoutData(gd);
        groupOne.setText("Group 1");
        
        new Text(groupOne, SWT.BORDER).setText("Enabled Text Field");
        
        Text txtDisabled = new Text(groupOne, SWT.BORDER);
        txtDisabled.setText("Disabled Text Field");
        txtDisabled.setEnabled(false);
        
        final Text txtOne = new Text(groupOne, SWT.BORDER);
        txtOne.setText("Toggle Text");
        
        //Group 1a
        final PropagateGroup groupOneA = new PropagateGroup(groupOne, SWT.FLAT);
        groupOneA.setLayout(new GridLayout(3, true));
        gd = new GridData(SWT.FILL, SWT.FILL, true, false);
        gd.horizontalSpan = 3;
        groupOneA.setLayoutData(gd);
        groupOneA.setText("Group 1A");
        
        final Combo cmbEnabled = new Combo(groupOneA, SWT.BORDER);
        cmbEnabled.setItems(new String[] {"Enabled Combo"});
        cmbEnabled.select(0);
        
        final Combo cmbDisabled = new Combo(groupOneA, SWT.BORDER);
        cmbDisabled.setItems(new String[] {"Disabled Combo"});
        cmbDisabled.setEnabled(false);
        cmbDisabled.select(0);
        
        final Combo cmbToggle = new Combo(groupOneA, SWT.BORDER);
        cmbToggle.setItems(new String[] {"Toggle Combo"});
        cmbToggle.select(0);
        
        //SWT Group
        final Group sWTGroup = new Group(contentGroup, SWT.FLAT);
        sWTGroup.setLayout(new GridLayout(2, true));
        GridData griddata = new GridData(SWT.FILL, SWT.FILL, true, false);
        griddata.horizontalSpan = 3;
        sWTGroup.setLayoutData(griddata);
        sWTGroup.setText("SWT Group");
        
        final Text txtSWTEnabled = new Text(sWTGroup, SWT.BORDER);
        txtSWTEnabled.setText("Enabled Text");
        
        final Text txtSWTDisabled = new Text(sWTGroup, SWT.BORDER);
        txtSWTDisabled.setText("Disabled Text");
        txtSWTDisabled.setEnabled(false);
        
        Label spacer = new Label(shell, SWT.NONE);
        spacer.setLayoutData(gd);
        
        Label seperator = new Label(shell, SWT.SEPARATOR | SWT.HORIZONTAL);
        seperator.setLayoutData(gd);
        
        //Button Composite
        final Composite buttonComposite = new Composite(shell, SWT.NONE);
        buttonComposite.setLayout(new RowLayout());
        
        final Button btnCompositeRoot = new Button(buttonComposite, SWT.TOGGLE);
        btnCompositeRoot.setText("Content Group");        
        
        final Button btnButton = new Button(buttonComposite, SWT.TOGGLE);
        btnButton.setText("Toggle Button");
        
        final Button btnComposite1 = new Button(buttonComposite, SWT.TOGGLE);
        btnComposite1.setText("Group 1");   
        
        final Button btnText1 = new Button(buttonComposite, SWT.TOGGLE);
        btnText1.setText("Toggle Text");
        
        final Button btnComposite1a = new Button(buttonComposite, SWT.TOGGLE);
        btnComposite1a.setText("Group 1a");
        
        final Button btnCombo = new Button(buttonComposite, SWT.TOGGLE);
        btnCombo.setText("Toggle Combo");
        
        final Button btnSWTComposite = new Button(buttonComposite, SWT.TOGGLE);
        btnSWTComposite.setText("SWT Group");
        
        btnSWTComposite.addSelectionListener(new SelectionAdapter(){
            @Override
            public void widgetSelected(SelectionEvent e) {
                sWTGroup.setEnabled(!btnSWTComposite.getSelection());
            }
        });
        
        btnCompositeRoot.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                contentGroup.setEnabled(!btnCompositeRoot.getSelection());
            }
        });
        
        btnButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                contentGroup.setEnabledOfChild(btnToggle, !btnButton.getSelection());
            }
        });
        
        btnText1.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                groupOne.setEnabledOfChild(txtOne, !btnText1.getSelection());
            }
        });
        
        btnComposite1.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                contentGroup.setEnabledOfChild(groupOne, !btnComposite1.getSelection());
            }
        });
        
        btnComposite1a.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                groupOne.setEnabledOfChild(groupOneA, !btnComposite1a.getSelection());
            }
        });
        
        btnCombo.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                groupOneA.setEnabledOfChild(cmbToggle, !btnCombo.getSelection());
            }
        });
        
        
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        
    }
}
