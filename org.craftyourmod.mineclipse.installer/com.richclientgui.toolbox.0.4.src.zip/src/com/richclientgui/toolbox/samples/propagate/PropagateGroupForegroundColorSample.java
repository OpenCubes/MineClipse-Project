/*
 * Created on 19 Oct 2007
 * Copyright 2007 Polymorph Systems Products
 */
package com.richclientgui.toolbox.samples.propagate;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.richclientgui.toolbox.propagate.PropagateGroup;

/**
 * @author Carien van Zyl
 */
public class PropagateGroupForegroundColorSample {

    public static void main(String[] args) {
        final Display display = new Display();
        final Shell shell = new Shell(display);
        shell.setText("Propagate Group Foreground Colour Sample");
        
        shell.setLayout(new GridLayout(4, false));
        
        final PropagateGroup mainGroup = new PropagateGroup(shell, SWT.FLAT);
        mainGroup.setLayout(new GridLayout());
        final GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        gd.horizontalSpan = 4;
        mainGroup.setLayoutData(gd);
        mainGroup.setText("Main Group");
        
        final Text txtOne = new Text(mainGroup, SWT.BORDER);
        txtOne.setText("Default 'Text' on Main");
        txtOne.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtTwo = new Text(mainGroup, SWT.BORDER);
        txtTwo.setText("Set to  be excluded from propagate foreground on Main");
        txtTwo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        mainGroup.excludeFromPropagateForeground(txtTwo);
        
        final PropagateGroup group1 = new PropagateGroup(mainGroup, SWT.FLAT);
        group1.setLayout(new GridLayout());
        group1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        group1.setText("Group 1 - set to propagate foreground");
        group1.setPropagateForeground(true);
        
        final Text txtInclude = new Text(group1, SWT.BORDER);
        txtInclude.setText("Default 'Text' on Group 1");
        txtInclude.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Text txtExclude = new Text(group1, SWT.BORDER);
        txtExclude.setText("Set to  be excluded from propagate foreground on Group 1");
        txtExclude.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        group1.excludeFromPropagateForeground(txtExclude);
        
        final PropagateGroup group2 = new PropagateGroup(mainGroup, SWT.FLAT);
        group2.setLayout(new GridLayout());
        group2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        mainGroup.excludeFromPropagateForeground(group2);
        group2.setText("Group 2");
        group2.setPropagateForeground(true);
        
        final Text txtIllustrate = new Text(group2, SWT.BORDER);
        txtIllustrate.setText("Default 'Text' on Group 2");
        txtIllustrate.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnBlue = new Button(shell, SWT.PUSH);
        btnBlue.setText("Blue");
        btnBlue.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                mainGroup.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_BLUE));        
            } 
        });
        btnBlue.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnRed = new Button(shell, SWT.PUSH);
        btnRed.setText("Red");
        btnRed.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                mainGroup.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_RED));
            } 
        });
        btnRed.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnToggle = new Button(shell, SWT.TOGGLE);
        btnToggle.setText("Propagate Foreground");
        btnToggle.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                mainGroup.setPropagateForeground(btnToggle.getSelection());
            }
        });
        mainGroup.setPropagateForeground(true);
        btnToggle.setSelection(true);
        btnToggle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        final Button btnToggleComposite2 = new Button(shell, SWT.TOGGLE);
        btnToggleComposite2.setText("Include Group 2");
        btnToggleComposite2.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                final boolean include = btnToggleComposite2.getSelection();
                if (include) {
                    mainGroup.includePropagateForeground(group2);
                } else {
                    mainGroup.excludeFromPropagateForeground(group2);
                }
            }
        });
        btnToggleComposite2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
        
        
        shell.open();
        shell.pack();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
    }
}
