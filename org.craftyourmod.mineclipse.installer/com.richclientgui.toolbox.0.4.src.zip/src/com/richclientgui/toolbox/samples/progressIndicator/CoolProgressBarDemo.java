package com.richclientgui.toolbox.samples.progressIndicator;

import static com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry.getImage;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.progressIndicator.CoolProgressBar;
import com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry;

public class CoolProgressBarDemo {
	
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = getShell(display);
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	public static Shell getShell(Display display){
		final Shell shell = new Shell(display);
		shell.setText("CoolProgressBar Demo");
		shell.setLayout(new GridLayout());
		new CoolProgressBarDemo(shell);
		shell.setLocation(Display.getDefault().getBounds().width/2 - 220,
				Display.getDefault().getBounds().height/2 - 220);
		shell.open();
		shell.pack();
		shell.setSize(440,440);		
		return shell;
	}
	
	private final Timer timer1 = new Timer();
	private final Timer timer2 = new Timer();
	private TimerTask timerTask1;
	private TimerTask timerTask2;
	private int cntBar1 = 0;
	private int cntBar2 = 0;
	private int cntBar3 = 0;
	private int cntBar4 = 0;
	private boolean disposed = false;
	
	public CoolProgressBarDemo(Shell shell){
		final Composite composite = new Composite(shell,SWT.NONE);
		composite.setLayout(new GridLayout(1,false));
		composite.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));		
		createProgressBars(composite);
		composite.addDisposeListener(new DisposeListener(){
			public void widgetDisposed(DisposeEvent arg0) {
				dispose();
			}
		});
	}
	
	private void dispose(){
		disposed = true;
		if(timerTask1 != null){
			timerTask1.cancel();
		}
		if(timerTask2 != null){
			timerTask2.cancel();
		}
		if(timer1 != null){
			timer1.cancel();
			timer1.purge();
		}
		if(timer2 != null){
			timer2.cancel();
			timer2.purge();
		}		
	}
	
	private void createProgressBars(Composite composite){
		final Group horizontal = new Group(composite,SWT.NONE);
		horizontal.setText("Horizontal");
		horizontal.setLayout(new GridLayout(1,false));
		horizontal.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));		
		
		final CoolProgressBar c1 = new CoolProgressBar(horizontal,SWT.HORIZONTAL,
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_LEFT_BORDER),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_FILLED),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_EMPTY),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_RIGHT_BORDER));
		c1.setLayoutData(new GridData(SWT.FILL,SWT.BEGINNING,true,false));
		
		final CoolProgressBar c2 = new CoolProgressBar(horizontal,SWT.HORIZONTAL,
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_LEFT_BORDER),
				getImage(SampleToolBoxImageRegistry.IMG_FILLED_REGION),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_EMPTY),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_RIGHT_BORDER));
		c2.setLayoutData(new GridData(SWT.FILL,SWT.BEGINNING,true,false));

		
		final Group vertical = new Group(composite,SWT.NONE);
		vertical.setText("Vertical");
		vertical.setLayout(new GridLayout(2,false));
		final GridData gd = new GridData(SWT.FILL,SWT.FILL,true,true);
		gd.heightHint = 300;
		vertical.setLayoutData(gd);	
		
		final CoolProgressBar c3 = new CoolProgressBar(vertical,SWT.VERTICAL,
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_BORDER_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_FILLED_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_EMPTY_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_BORDER_VERTICAL));
		c3.setLayoutData(new GridData(SWT.BEGINNING,SWT.FILL,false,true));
		
		final CoolProgressBar c4 = new CoolProgressBar(vertical,SWT.VERTICAL,
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_BORDER_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_FILLED_REGION_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_EMPTY_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_PROGRESS_BAR_BORDER_VERTICAL));
		c4.setLayoutData(new GridData(SWT.BEGINNING,SWT.FILL,false,true));
				
		timerTask1 = new TimerTask(){
			@Override
			public void run() {
				if(disposed)return;
				Display.getDefault().syncExec(new Runnable(){
					public void run() {
						if(disposed)return;
						c1.updateProgress(cntBar1/100.0);						
						c2.updateProgress(cntBar2/100.0);
						cntBar1++;
						cntBar2+=2;
						if(cntBar1 > 100) cntBar1 = 0;
						if(cntBar2 > 100) cntBar2 = 0;
					}					
				});				
			}
		};
		timer1.schedule(timerTask1,100,50);		
		
		timerTask2 = new TimerTask(){
			@Override
			public void run() {
				if(disposed)return;
				Display.getDefault().syncExec(new Runnable(){
					public void run() {
						if(disposed)return;
						c3.updateProgress(cntBar3/100.0);						
						c4.updateProgress(cntBar4/100.0);
						cntBar3+=2;
						cntBar4++;
						if(cntBar3 > 100) cntBar3 = 0;
						if(cntBar4 > 100) cntBar4 = 0;
					}					
				});				
			}
		};
		timer2.schedule(timerTask2,100,50);
	}
}
