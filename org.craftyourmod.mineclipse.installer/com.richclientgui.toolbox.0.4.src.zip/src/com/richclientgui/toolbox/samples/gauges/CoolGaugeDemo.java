package com.richclientgui.toolbox.samples.gauges;

import static com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry.getImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.gauges.CoolGauge;
import com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry;

public class CoolGaugeDemo {
	
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = getShell(display);
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
	
	public static Shell getShell(Display display){
		final Shell shell = new Shell(display);
		shell.setText("Cool Gauge Demo");
		shell.setLayout(new GridLayout());
		new CoolGaugeDemo(shell);
		shell.setLocation(Display.getDefault().getBounds().width/2-250,
				Display.getDefault().getBounds().height/2 - 250);
		shell.open();
		shell.pack();		
		return shell;
	}
	
	private final Timer timer = new Timer();
	private int cnt = 0;
	private int nextNumber = 0;
	private boolean up = false;
	private TimerTask task; 
	private static final int PERIOD = 20;
	private boolean disposed = false;
	
	public CoolGaugeDemo(Shell shell){
		final Composite composite = new Composite(shell,SWT.NONE);
		composite.setLayout(new GridLayout(1,false));
		composite.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));		
		createGauges(composite);
		composite.addDisposeListener(new DisposeListener(){
			public void widgetDisposed(DisposeEvent arg0) {
				disposed = true;
				if(task!=null)
					task.cancel();				
				timer.purge();
				timer.cancel();
			}
		});
	}

	
	private void createGauges(Composite parent){
		final CoolGauge gauge = new CoolGauge(parent,getImage(SampleToolBoxImageRegistry.IMG_GAUGE_CIRCLE_4));
		gauge.setLayoutData(new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false));
		gauge.setGaugeNeedleColour(Display.getDefault().getSystemColor(SWT.COLOR_RED));
		gauge.setGaugeNeedleWidth(2);
		gauge.setGaugeNeedlePivot(new Point(176,175));
		gauge.setGaugeNeedlePivotImage(getImage(SampleToolBoxImageRegistry.IMG_GAUGE_CIRCLE_4_PIVOT));					
		gauge.setPoints(getPnts());
		
		final CoolGauge gaugeTop = new CoolGauge(parent,getImage(SampleToolBoxImageRegistry.IMG_GAUGE_TOP_HALF_CIRCLE));
		gaugeTop.setLayoutData(new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false));
		gaugeTop.setGaugeNeedleColour(Display.getDefault().getSystemColor(SWT.COLOR_RED));
		gaugeTop.setGaugeNeedleWidth(2);
		gaugeTop.setGaugeNeedlePivot(new Point(153,162));
		gaugeTop.setGaugeNeedlePivotImage(getImage(SampleToolBoxImageRegistry.IMG_GAUGE_ORANGE_PIVOT));					
		gaugeTop.setPoints(getTopCircleGaugePnts());
		
		final CoolGauge gaugeLeft = new CoolGauge(parent,getImage(SampleToolBoxImageRegistry.IMG_GAUGE_LEFT_HALF_CIRCLE));
		gaugeLeft.setLayoutData(new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false));
		gaugeLeft.setGaugeNeedleColour(Display.getDefault().getSystemColor(SWT.COLOR_RED));
		gaugeLeft.setGaugeNeedleWidth(2);
		gaugeLeft.setGaugeNeedlePivot(new Point(161,154));
		gaugeLeft.setGaugeNeedlePivotImage(getImage(SampleToolBoxImageRegistry.IMG_GAUGE_ORANGE_PIVOT));					
		gaugeLeft.setPoints(getLeftHalfCircleGaugePnts());
		
		nextNumber = (int)(Math.random()*100);
		up = true;
		task = new TimerTask(){			
			@Override
			public void run() {
				if(disposed)return;
				Display.getDefault().asyncExec(new Runnable(){
					public void run() {		
						if(disposed)return;
						gauge.setLevel(cnt/100.0);
						gaugeTop.setLevel(cnt/100.0);
						gaugeLeft.setLevel(cnt/100.0);
						if(up){
							cnt+=1;	
						}else{
							cnt-=1;
						}		
						if(cnt == nextNumber){
							do{
								getNextNumber();								
								up = cnt<nextNumber;
							}while(cnt == nextNumber);
						}						
 					}
				});
			}
		};
		timer.schedule(task,1000,PERIOD);
		
		gauge.addDisposeListener(new DisposeListener(){
			public void widgetDisposed(DisposeEvent arg0) {				
				timer.cancel();
				timer.purge();
			}
		});
	}
	
	private void getNextNumber(){
		nextNumber = (int)(Math.random()*100);
		if(nextNumber > 100){
			nextNumber = 100;							
		}
		if(nextNumber < 0){
			nextNumber = 0;
		}
	}
	
	private List<Point> getPnts(){
		final List<Point> pnts = new ArrayList<Point>();
		pnts.add(new Point(115,280)); 
		pnts.add(new Point(105,275));
		pnts.add(new Point(97,270));
		pnts.add(new Point(88,262));		
		pnts.add(new Point(81,253));
		pnts.add(new Point(72,236)); 
		pnts.add(new Point(65,225));
		pnts.add(new Point(61,217));		
		pnts.add(new Point(58,206));
		pnts.add(new Point(56,206));
		pnts.add(new Point(55,187));
		pnts.add(new Point(55,175));
		pnts.add(new Point(55,163));
		pnts.add(new Point(55,153));
		pnts.add(new Point(58,143));
		pnts.add(new Point(61,134));
		pnts.add(new Point(65,124));
		pnts.add(new Point(71,116));
		pnts.add(new Point(77,105));
		pnts.add(new Point(83,99));
		pnts.add(new Point(90,90));
		pnts.add(new Point(97,84));
		pnts.add(new Point(106,77));
		pnts.add(new Point(115,71));
		pnts.add(new Point(127,65));
		pnts.add(new Point(134,61));
		pnts.add(new Point(145,58));
		pnts.add(new Point(154,56));
		pnts.add(new Point(165,54));
		pnts.add(new Point(175,54));
		pnts.add(new Point(186,55));
		pnts.add(new Point(197,56));
		pnts.add(new Point(206,56));
		pnts.add(new Point(216,61));
		pnts.add(new Point(225,64));
		pnts.add(new Point(236,71));
		pnts.add(new Point(246,76));
		pnts.add(new Point(255,81));
		pnts.add(new Point(261,89));
		pnts.add(new Point(268,97));
		pnts.add(new Point(274,105));
		pnts.add(new Point(280,115));
		pnts.add(new Point(285,124));
		pnts.add(new Point(289,134));
		pnts.add(new Point(293,144));
		pnts.add(new Point(296,154));
		pnts.add(new Point(296,164));
		pnts.add(new Point(296,175));
		pnts.add(new Point(295,186));
		pnts.add(new Point(294,194));
		pnts.add(new Point(292,206));
		pnts.add(new Point(286,215));
		pnts.add(new Point(285,225));
		pnts.add(new Point(280,235));
		pnts.add(new Point(275,245));
		pnts.add(new Point(269,252));
		pnts.add(new Point(261,261));
		pnts.add(new Point(253,268));
		pnts.add(new Point(245,274));
		pnts.add(new Point(235,280));
		return pnts;
	}
	
	private List<Point> getTopCircleGaugePnts(){
		final List<Point> pnts = new ArrayList<Point>();
		pnts.add(new Point(33,161)); 
		pnts.add(new Point(33,150));
		pnts.add(new Point(33,143));
		pnts.add(new Point(34,133));		
		pnts.add(new Point(36,123));
		pnts.add(new Point(39,113)); 
		pnts.add(new Point(42,105));
		pnts.add(new Point(46,96));		
		pnts.add(new Point(53,88));
		pnts.add(new Point(58,79));
		pnts.add(new Point(63,73));
		pnts.add(new Point(71,65));
		pnts.add(new Point(79,59));
		pnts.add(new Point(88,59));
		pnts.add(new Point(94,47));
		pnts.add(new Point(104,42));
		pnts.add(new Point(114,39));
		pnts.add(new Point(124,36));
		pnts.add(new Point(132,34));
		pnts.add(new Point(143,33));
		pnts.add(new Point(154,34));
		pnts.add(new Point(165,33));
		pnts.add(new Point(173,34));
		pnts.add(new Point(182,35));
		pnts.add(new Point(193,39));
		pnts.add(new Point(202,42));
		pnts.add(new Point(211,45));
		pnts.add(new Point(220,50));
		pnts.add(new Point(228,58));
		pnts.add(new Point(236,65));
		pnts.add(new Point(244,71));
		pnts.add(new Point(249,78));
		pnts.add(new Point(255,87));
		pnts.add(new Point(262,95));
		pnts.add(new Point(266,104));
		pnts.add(new Point(269,111));
		pnts.add(new Point(271,123));
		pnts.add(new Point(273,132));
		pnts.add(new Point(274,140));
		pnts.add(new Point(275,149));
		pnts.add(new Point(274,161));
		return pnts;
	}
	
	private List<Point> getLeftHalfCircleGaugePnts(){
		final List<Point> pnts = new ArrayList<Point>();
		pnts.add(new Point(161,274)); 
		pnts.add(new Point(150,274));
		pnts.add(new Point(142,273));
		pnts.add(new Point(132,273));		
		pnts.add(new Point(123,270));
		pnts.add(new Point(112,267)); 
		pnts.add(new Point(104,264));
		pnts.add(new Point(96,260));		
		pnts.add(new Point(87,255));
		pnts.add(new Point(78,249));
		pnts.add(new Point(71,244));
		pnts.add(new Point(64,236));
		pnts.add(new Point(59,228));
		pnts.add(new Point(51,220));
		pnts.add(new Point(47,213));
		pnts.add(new Point(41,208));
		pnts.add(new Point(39,193));
		pnts.add(new Point(34,184));
		pnts.add(new Point(34,176));
		pnts.add(new Point(33,165));
		pnts.add(new Point(33,154));
		pnts.add(new Point(33,143));
		pnts.add(new Point(34,134));
		pnts.add(new Point(36,124));
		pnts.add(new Point(39,114));
		pnts.add(new Point(43,104));
		pnts.add(new Point(46,97));
		pnts.add(new Point(51,87));
		pnts.add(new Point(59,79));
		pnts.add(new Point(65,71));
		pnts.add(new Point(70,65));
		pnts.add(new Point(78,58));
		pnts.add(new Point(87,53));
		pnts.add(new Point(96,46));
		pnts.add(new Point(103,43));
		pnts.add(new Point(113,40));
		pnts.add(new Point(123,37));
		pnts.add(new Point(133,33));
		pnts.add(new Point(141,32));
		pnts.add(new Point(151,33));
		pnts.add(new Point(161,33));
		return pnts;
	}
}

