package com.richclientgui.toolbox.samples.button;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.button.CoolButton;
import com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry;

public class CoolButtonDemo {
	
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = getShell(display);
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	public static Shell getShell(Display display){
		final Shell shell = new Shell(display);
		shell.setText("CoolButton Demo");
		shell.setLayout(new GridLayout());
		new CoolButtonDemo(shell);
		shell.setLocation(Display.getDefault().getBounds().width/2 - 100,
				Display.getDefault().getBounds().height/2 - 50);
		shell.open();
		shell.pack();
		shell.setSize(230, 300);
		return shell;
	}
	
	public CoolButtonDemo(Shell parent){
		final Composite composite = new Composite(parent,SWT.NONE);
		composite.setLayout(new GridLayout(1,false));
		composite.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));		
		createPushButtonGroup(composite);
		createToggledButtonGroup(composite);
	}
	
	private void createToggledButtonGroup(Composite composite){
		final Group toggleButtons = new Group(composite,SWT.NONE);
		toggleButtons.setText("Toggle Button");
		toggleButtons.setLayout(new GridLayout(2,false));
		toggleButtons.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		
		final CoolButton c = new CoolButton(toggleButtons,
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_NORMAL),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_HOVER),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_PRESSED),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_NORMAL_TOGGLED),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_HOVER_TOGGLED),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_PRESSED_TOGGLED));
		c.setHotRegionMask(SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_HOT_SPOT));
		c.setHotToggledRegionMask(SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_HOT_SPOT_TOGGLED));
		final GridData gd = new GridData(SWT.BEGINNING,SWT.BEGINNING,false,false);
		gd.verticalSpan = 2;
		c.setLayoutData(gd);
			
		final Button but = new Button(toggleButtons,SWT.CHECK);
		but.setText("Hot Spot");
		but.setSelection(true);
		but.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				c.setHotRegionMask(but.getSelection()?SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_HOT_SPOT):null);
			}
		});
	
		final Button but1 = new Button(toggleButtons,SWT.CHECK);
		but1.setText("Hot Spot (Toggled State)");
		but1.setSelection(true);
		but1.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				c.setHotToggledRegionMask(but.getSelection()?SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CHECKBOX_HOT_SPOT):null);
			}
		});
	}
	
	private void createPushButtonGroup(Composite composite){
		final Group pushButtons = new Group(composite,SWT.NONE);
		pushButtons.setText("Push Buttons");
		pushButtons.setLayout(new GridLayout(2,true));
		pushButtons.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		
		new CoolButton(pushButtons,
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CIRCLE_RED_NORMAL),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CIRCLE_RED_HOVER),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_CIRCLE_RED_PRESSED));
	
		final CoolButton c = new CoolButton(pushButtons,
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_SQUARE_BLUE_NORMAL),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_SQUARE_BLUE_HOVER),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_SQUARE_BLUE_PRESSED));
		c.setLayoutData(new GridData(SWT.END,SWT.CENTER,true,true));
		
		new CoolButton(pushButtons,
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_LEFT_NORMAL),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_LEFT_HOVER),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_LEFT_PRESSED));
		
		final CoolButton cc = new CoolButton(pushButtons,
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_RIGHT_NORMAL),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_RIGHT_HOVER),
				SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_RIGHT_PRESSED));
		cc.setHotRegionMask(SampleToolBoxImageRegistry.getImage(SampleToolBoxImageRegistry.IMG_BUTTON_PUSH_RIGHT_HOT_REGION));
		cc.setLayoutData(new GridData(SWT.END,SWT.CENTER,true,true));
		
	}
}
