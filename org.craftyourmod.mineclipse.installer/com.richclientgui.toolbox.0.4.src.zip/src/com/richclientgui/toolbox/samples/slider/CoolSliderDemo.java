package com.richclientgui.toolbox.samples.slider;

import static com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry.getColor;
import static com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry.getImage;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;

import com.richclientgui.toolbox.samples.images.SampleToolBoxImageRegistry;
import com.richclientgui.toolbox.slider.CoolSlider;
import com.richclientgui.toolbox.slider.CoolSliderPositionChangeListener;
import com.richclientgui.toolbox.slider.CoolSliderToolTipInterpreter;

public class CoolSliderDemo {

	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = getShell(display);		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	public static Shell getShell(Display display){
		final Shell shell = new Shell(display);
		shell.setText("CoolSlider Demo");
		shell.setLayout(new GridLayout());		
		shell.setLocation(Display.getDefault().getBounds().width/2 - 100,
				Display.getDefault().getBounds().height/2 - 50);
		new CoolSliderDemo(shell);
		shell.open();
		shell.pack();
		shell.setSize(300,300);
		return shell;
	}
	
	public CoolSliderDemo(Shell shell){
		final Composite composite = new Composite(shell,SWT.NONE);
		composite.setLayout(new GridLayout(2,false));
		composite.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));

		createSmoothSliders(composite);
		createSnapSliders(composite);
	}
	
	private void createSnapSliders(Composite composite){
		final Group sliders = new Group(composite,SWT.NONE);
		sliders.setText("Snap Sliders");
		sliders.setLayout(new GridLayout(1,false));
		sliders.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));		
		
		final Composite comp = new Composite(sliders,SWT.NONE);
		comp.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,false));
		comp.setLayout(new GridLayout(1,false));
		comp.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		
		final CoolSlider c1 = new CoolSlider(comp,SWT.HORIZONTAL|CoolSlider.SNAP_STYLE,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT_MOST),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT_MOST));
		c1.setLayoutData(new GridData(SWT.FILL,SWT.BEGINNING,true,false));
		c1.setSnapValues(100, 0, 20);
		c1.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		c1.setKeyMoveIncrement(20);
		
		final CoolSlider c2 = new CoolSlider(comp,SWT.HORIZONTAL|CoolSlider.SNAP_STYLE,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT_MOST),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT_MOST));
		c2.setLayoutData(new GridData(SWT.FILL,SWT.BEGINNING,true,false));
		c2.setSnapValues(100, 0, 10);
		c2.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		c2.setKeyMoveIncrement(10);
		
		final Composite compV = new Composite(sliders,SWT.NONE);
		compV.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		compV.setLayout(new GridLayout(2,false));
		compV.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		final CoolSlider cv = new CoolSlider(compV,SWT.VERTICAL|CoolSlider.SNAP_STYLE,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT_MOST_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT_MOST_VERTICAL));	
		cv.setLayoutData(new GridData(SWT.BEGINNING,SWT.FILL,false,true));
		cv.setSnapValues(100, 0, 10);
		cv.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		cv.setKeyMoveIncrement(10);
		
		final CoolSlider cv1 = new CoolSlider(compV,SWT.VERTICAL|CoolSlider.SNAP_STYLE,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT_MOST_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT_MOST_VERTICAL));
		cv1.setLayoutData(new GridData(SWT.BEGINNING,SWT.FILL,false,true));
		cv1.setKeyMoveIncrement(20);
		cv1.setSnapValues(100,20,10);
		cv1.addPositionChangeListener(new CoolSliderPositionChangeListener(){
			public void positionChanged(double position) {
				System.out.println("Position = " + position);
				System.out.println("");			 	
			}
		});
		cv1.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		cv1.setTooltipInterperter(new CoolSliderToolTipInterpreter(){

			public String getToolTipForPositionOnMouseHover(double percentage) {				
				return String.valueOf(percentage);
			}

			public String getToolTipForPositionOnMouseMoveOver(double percentage) {
				return String.valueOf(percentage);
			}
			
		});
		
	}

	private void createSmoothSliders(Composite composite){
		final Group sliders = new Group(composite,SWT.NONE);
		sliders.setText("Smooth Sliders");
		sliders.setLayout(new GridLayout(1,false));
		sliders.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));		
		
		final Composite comp = new Composite(sliders,SWT.NONE);
		comp.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,false));
		comp.setLayout(new GridLayout(1,false));
		comp.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		final CoolSlider c1 = new CoolSlider(comp,SWT.HORIZONTAL,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT_MOST),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT_MOST));
		c1.setLayoutData(new GridData(SWT.FILL,SWT.BEGINNING,true,false));
		c1.setKeyMoveIncrement(0.1);
		
		final CoolSlider c2 = new CoolSlider(comp,SWT.HORIZONTAL,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT_MOST),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT_MOST));
		c2.setLayoutData(new GridData(SWT.FILL,SWT.BEGINNING,true,false));
		c2.setKeyMoveIncrement(0.1);
		
		final Composite compV = new Composite(sliders,SWT.NONE);
		compV.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		compV.setLayout(new GridLayout(2,false));
		compV.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		
		final CoolSlider cv = new CoolSlider(compV,SWT.VERTICAL,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT_MOST_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_LEFT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER_RIGHT_MOST_VERTICAL));	
		cv.setLayoutData(new GridData(SWT.BEGINNING,SWT.FILL,false,true));
		cv.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		cv.setKeyMoveIncrement(0.1);
		
		final CoolSlider cv1 = new CoolSlider(compV,SWT.VERTICAL,
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT_MOST_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_LEFT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_THUMB_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT_VERTICAL),
				getImage(SampleToolBoxImageRegistry.IMG_SLIDER2_RIGHT_MOST_VERTICAL));
		cv1.setLayoutData(new GridData(SWT.BEGINNING,SWT.FILL,false,true));
		cv1.setKeyMoveIncrement(0.1);
		cv1.addPositionChangeListener(new CoolSliderPositionChangeListener(){
			public void positionChanged(double position) {
				System.out.println("Position = " + position);
				System.out.println("");			 	
			}
		});
		cv1.setBackground(getColor(SampleToolBoxImageRegistry.COLOR_DARK_SLIDER));
		cv1.setTooltipInterperter(new CoolSliderToolTipInterpreter(){

			public String getToolTipForPositionOnMouseHover(double percentage) {				
				return String.valueOf(percentage);
			}

			public String getToolTipForPositionOnMouseMoveOver(double percentage) {
				return String.valueOf(percentage);
			}
			
		});
		
	}
}
