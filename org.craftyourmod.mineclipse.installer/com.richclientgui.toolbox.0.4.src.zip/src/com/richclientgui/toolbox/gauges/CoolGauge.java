package com.richclientgui.toolbox.gauges;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.LineAttributes;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
/** 
 * The <code>CoolGauge</code> is widget that provides the developer a means to create a custom gauge.
 * Gauges can be used to give the end-user a graphical representation of the status or any monitored component.
 * <br><br>
 * The <code>CoolGauge</code> will always have a single pivot point for its needle. The <code>CoolGauge</code> is more
 * suited to circular gauges.<br>
 * 
 * To create a <code>CoolGauge</code> the developer will need to create the graphical look of the gauge by means of an image. 
 * The developer will then specify pixel points on the gauge that will represent the path that the 
 * gauge needle will take when expressing the level of the gauge. More points specified the better.<br>
 * 
 * The needle's length, color, width, style can be specified.<br><br>
 * 
 * An image to "cover" the needle's pivot point can be specified. <br><br>
 * 
 * To set the level of the gauge the developer must specify a percentage from 0->1 (i.e 0% to 100%). This will then move the 
 * gauge needle according to the set of points specified by the user.<br><br>
 * 
 * NOTE: The gauge needle will be able to move to positions between the points specified.
 * 
 * <br><br>
 * Sample on how to use the <code>CoolGauge</code> is provided in the samples package.
 * <br><br>
 * 
 * @author Code Crofter
 * on behalf Polymorph Systems
 * 
 * @since RCP Toolbox v0.2 <br>
 * 
 */
public class CoolGauge extends Canvas {
	private final List<Point> points = new ArrayList<Point>();
	private final List<Integer> distanceToNextPoint = new ArrayList<Integer>();
	private final Image gaugeImage;
	private Image needlePivotPointImage;
	private Point needlePivotPoint;
	private Color needleColor;
	private int needleLength = 0;
	private Point currentNeedlePosition;
	private int needleWidth = 1;
	private int totalDistance = 0;
	private int swt_cap_style = SWT.CAP_FLAT;
	private int swt_line_style = SWT.LINE_SOLID;
	private LineAttributes lineAttributes;
	
	/**
	 * Creates a <code>CoolGauge</code> with the specified image 
	 * @param parent
	 * @param gaugeImage - The image representing the face of the gauge.
	 */
	public CoolGauge(Composite parent, Image gaugeImage) {
		super(parent, SWT.DOUBLE_BUFFERED);
		this.gaugeImage = gaugeImage;
		if(gaugeImage == null){
			throw new IllegalArgumentException("The gauge image must not be null.");
		}
		addPaintListener(new PaintListener(){
			public void paintControl(PaintEvent e) {
				CoolGauge.this.paintControl(e);
			}
		});
	}
	
	/** This will be used to set some of the attributes of the needle. 
	 * Look at the javadocs under <code>GC.setLineAttributes()</code>
	 * If this is non null then it will take priority over the other individual settings.*/
	public void setNeedleLineAttributes(LineAttributes lineAttributes){
		checkWidget();
		this.lineAttributes = lineAttributes;
		redrawNeedle();
	}
	/** Sets the line style for the needle look at <code>GC.setLineStyle(int style)*/
	public void setNeedleLineStyle(int swt_line_style){
		checkWidget();
		this.swt_line_style = swt_line_style;
		redrawNeedle();
	}
	/** Sets the style for the end point of the needle look at <code>GC.setLineCap(int cap)*/
	public void setNeedleCap(int swt_cap_style){
		checkWidget();
		this.swt_cap_style = swt_cap_style;
		redrawNeedle();
	}

	private void paintControl(PaintEvent e){
		final Image image = new Image(e.display,gaugeImage.getImageData());
		final GC gc = new GC(image);		
		gc.setAdvanced(true);
		gc.setAntialias(SWT.ON);
		
		// draw the needle
		gc.setForeground(needleColor);
		gc.setLineWidth(needleWidth);
		gc.setLineCap(swt_cap_style);
		gc.setLineStyle(swt_line_style);
		if(lineAttributes != null){
			gc.setLineAttributes(lineAttributes);
		}				
		final Point pnt = needlePivotPoint;
		if(currentNeedlePosition != null){			
			gc.drawLine(pnt.x, pnt.y, currentNeedlePosition.x, currentNeedlePosition.y);
		}		
		// overlay the image for the needle pivot point
		if(needlePivotPointImage != null){
			final Rectangle rect = needlePivotPointImage.getBounds();
			gc.drawImage(needlePivotPointImage, pnt.x-rect.width/2, pnt.y-rect.height/2);
		}		
		e.gc.drawImage(image, 0, 0);
		gc.dispose();
		image.dispose();
	}
	
	/** The points that will form a path that the gauge needle will follow. */
	public void setPoints(List<Point> points){
		checkWidget();
		this.points.clear();
		this.points.addAll(points);
		final int size = this.points.size();
		int totalDistance = 0;
		for(int i = 0; i < size; i++){
			final Point pnt0 = this.points.get(i);
			Point pnt1 = pnt0;
			if((i+1) < size){
				pnt1 = this.points.get(i+1);
			}
			final int dis = getShortestDistance(pnt0,pnt1)+1;
			totalDistance+=dis;
			distanceToNextPoint.add(new Integer(dis));
		}
		if(size > 0){
			currentNeedlePosition = points.get(0);
		}
		this.totalDistance = totalDistance;
		redrawNeedle();
	}
	
	private int getShortestDistance(Point pnt0, Point pnt1){
		return (int)(Math.sqrt(Math.pow((pnt1.x-pnt0.x),2)+Math.pow((pnt1.y-pnt0.y),2)));
	}
	
	/** Get the current point for the distance along the short distances between points.*/
	private Point getCurrentPoint(int distance){
		final int size = distanceToNextPoint.size();
		int cnt = 0;
		for(int i = 0; i < size; i++){
			if(i+1 < size && cnt + distanceToNextPoint.get(i).intValue() >= distance){// about to go over the	
				return getPointBetweenIndices(i,i+1,distance-cnt);
			}
			cnt+=distanceToNextPoint.get(i).intValue();			
		}
		return points.get(size-1);
	}
	
	/** Get the point position for the offset between the points with indices: index0 and index1*/
	private Point getPointBetweenIndices(int index0, int index1, int offset){		
		final int startX = points.get(index0).x;
		final int startY = points.get(index0).y;
		final int endX = points.get(index1).x;
		final int endY = points.get(index1).y;
		final int width = Math.abs(endX-startX);
		final int height = Math.abs(endY-startY);
		final double hypot = Math.sqrt((Math.pow(width,2)+Math.pow(height, 2)));		
		final int newX = (int)(offset*width*1.0/hypot);
		final int newY = (int)(offset*height*1.0/hypot);
		// look at the need length
		final Point pnt = new Point(startX,startY);
		if(isQ1(startX,startY,endX,endY)){		//1st Quadrant
			pnt.x = startX-newX;
			pnt.y = startY-newY;
		}else if(isQ2(startX,startY,endX,endY)){//2nd Quadrant
			pnt.x = startX+newX;
			pnt.y = startY-newY;
		}else if(isQ3(startX,startY,endX,endY)){//3rd Quadrant
			pnt.x = startX-newX;
			pnt.y = startY+newY;
		}else if(isQ4(startX,startY,endX,endY)){//4th Quadrant
			pnt.x = startX+newX;
			pnt.y = startY+newY;
		}	
		if(needleLength > 0){
			final Point needle = needlePivotPoint;
			final int r = needleLength;
			final int R = getShortestDistance(needle, pnt);
			if(r != R){
				final int X = Math.abs(pnt.x-needle.x);
				final int Y = Math.abs(pnt.y-needle.y);
				final double rat = r*1.0/R;
				final int sX = (int)(X*rat);
				final int sY = (int)(Y*rat);
				if(isQ1(needle.x,needle.y,pnt.x,pnt.y)){	  //1st Quadrant
					pnt.x = needle.x - sX;
					pnt.y = needle.y - sY;
				}else if(isQ2(needle.x,needle.y,pnt.x,pnt.y)){//2nd Quadrant
					pnt.x = needle.x + sX;
					pnt.y = needle.y - sY;
				}else if(isQ3(needle.x,needle.y,pnt.x,pnt.y)){//3rd Quadrant
					pnt.x = needle.x - sX;
					pnt.y = needle.y + sY;
				}else if(isQ4(needle.x,needle.y,pnt.x,pnt.y)){//4th Quadrant
					pnt.x = needle.x+sX;
					pnt.y = needle.y+sY;
				}
			}						
		}
		return pnt;
	}
	
	/** The level that the gauge must display, a percentage from 0 to 1 (i.e 0% to 100%)*/
	public void setLevel(double percentage){	
		checkWidget();
		if(percentage < 0){
			percentage = 0;
		}else if(percentage > 1){
			percentage = 1;
		}
		redrawNeedle();				
		currentNeedlePosition = getCurrentPoint((int)(totalDistance*percentage));
		redrawNeedle();
	}
	
	private void redrawNeedle(){
		final int width = needleWidth;
		final int nX = needlePivotPoint.x;
		final int nY = needlePivotPoint.y;
		final int cX = currentNeedlePosition.x;
		final int cY = currentNeedlePosition.y;
		final int widthCxBigger = (cX-nX)<= 1?2+2*width:(cX-nX)+2*width;
		final int widthNxBigger = (nX-cX)<= 1?2+2*width:(nX-cX)+2*width;
		final int heightCyBigger = (cY-nY)<= 1?2+2*width:(cY-nY)+2*width;
		final int heightNyBigger = (nY-cY)<= 1?2+2*width:(nY-cY)+2*width;		
		if(isQ1(nX,nY,cX,cY)){		//1st Quadrant
			redraw(cX-width,cY-width,widthNxBigger,heightNyBigger,false);
		}else if(isQ2(nX,nY,cX,cY)){//2nd Quadrant			
			redraw(nX-width,cY-width,widthCxBigger,heightNyBigger,false);			
		}else if(isQ3(nX,nY,cX,cY)){//3rd Quadrant
			redraw(cX-width,nY-width,widthNxBigger,heightCyBigger,false);
		}else if(isQ4(nX,nY,cX,cY)){//4th Quadrant
			redraw(nX-width,nY-width,widthCxBigger,heightCyBigger,false);			
		}else{
			redraw();
		}
	}
	
	private boolean isQ1(int nX, int nY, int cX, int cY){
		return (nX >= cX && nY >= cY);//1st Quadrant
	}
	
	private boolean isQ2(int nX, int nY, int cX, int cY){
		return (nX <= cX && nY >= cY);//2nd Quadrant
	}
	
	private boolean isQ3(int nX, int nY, int cX, int cY){
		return (nX >= cX && nY <= cY);//3rd Quadrant
	}
	
	private boolean isQ4(int nX, int nY, int cX, int cY){
		return (nX <= cX && nY <= cY);//4rd Quadrant
	}
	
	/** Sets the needles pivot image*/
	public void setGaugeNeedlePivotImage(Image pivotImage){
		checkWidget();
		if(pivotImage == null){
			throw new IllegalArgumentException("The pivot image cannot be null");
		}
		needlePivotPointImage = pivotImage;
		if(needlePivotPoint != null && currentNeedlePosition != null){
			redrawNeedle();
		}else{
			redraw();
		}
	}
	
	/** Sets the needle's pivot point in pixels*/
	public void setGaugeNeedlePivot(Point point){
		checkWidget();
		if(point == null){
			throw new IllegalArgumentException("The point cannot be null");
		}
		needlePivotPoint = point;
		if(needlePivotPoint != null && currentNeedlePosition != null){
			redrawNeedle();
		}else{
			redraw();
		}
	}
	
	/** Sets the needle's colour*/
	public void setGaugeNeedleColour(Color colour){
		checkWidget();
		if(colour == null){
			throw new IllegalArgumentException("The color cannot be null");
		}
		needleColor = colour;
		if(needlePivotPoint != null && currentNeedlePosition != null){
			redrawNeedle();
		}else{
			redraw();
		}
	}
	/** Sets the needle's length from the pivot*/
	public void setGaugeNeedleLength(int length){
		checkWidget();
		if(length <= 0){
			throw new IllegalArgumentException("The needle length must be greater than 0");
		}
		needleLength = length;
		if(needlePivotPoint != null && currentNeedlePosition != null){
			redrawNeedle();
		}else{
			redraw();
		}
	}
	/** Sets the needle's width*/
	public void setGaugeNeedleWidth(int width){
		checkWidget();
		if(width <= 0){
			throw new IllegalArgumentException("The needle width must be greater than 0");
		}
		needleWidth = width;
		if(needlePivotPoint != null && currentNeedlePosition != null){
			redrawNeedle();
		}else{
			redraw();
		}
	}
	
	@Override
	public Point computeSize(int wHint, int hHint, boolean changed) {
		checkWidget();
		int width = 0, height = 0;
		if (gaugeImage != null && !gaugeImage.isDisposed()) {
			final Rectangle bounds = gaugeImage.getBounds();
			width = bounds.width;
			height = bounds.height;
		}		    
	    if (wHint != SWT.DEFAULT) width = wHint;
	    if (hHint != SWT.DEFAULT) height = hHint; 
		return new Point(width, height);    
	}
}
