package com.richclientgui.toolbox.googleMap;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

public class GoogleMapComposite extends Composite{
	private String url = "yourtravelcompanion.co.za/google_map_sample.htm";
	private Browser browser;
	
	public GoogleMapComposite(Composite parent, int style) {
		super(parent, style);
		setLayout();
		setBackground(Display.getDefault().getSystemColor(SWT.COLOR_BLUE));
		browser = new Browser(this,SWT.NONE);
		browser.setLayoutData(new GridData(SWT.FILL,SWT.FILL,true,true));
		browser.setUrl(url);
	}

	private void setLayout(){
		final GridLayout gl = new GridLayout(1,false);
		gl.marginHeight = 0;
		gl.marginWidth = 0;
		gl.horizontalSpacing = 0;
		gl.verticalSpacing = 0;
		setLayout(gl);
	}
	
	public void showMapFrom(String url){
		browser.setUrl(url);
	}
	
	public void refresh(){
		checkWidget();
		browser.refresh();
	}
}
