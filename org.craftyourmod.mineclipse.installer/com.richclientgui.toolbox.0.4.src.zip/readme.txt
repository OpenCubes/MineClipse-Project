RCP Toolbox (by Polymorph Systems Products, www.richclientgui.com)
==================================================================
Latest release: v0.4 (2008-06-24)

v0.4 (2008-06-24)
------------------
Widgets/Features added:
- PropagateGroup:	the PropagateGroup class can not also propagate changes to background and foreground colours

Fixes:
- CoolButton:		some minor fixes


v0.3 (2007-11-03)
------------------
Widgets/Features added:
-CoolGauge:		a Gauge widget that allows a custom look
-CoolSlider: 	PositionChangeListener has been added to listen for updates to thumb position
-CoolButton: 	now supports custom "hot area" image masks, so any black&white image can be provided as mask for button's
             	hot area, thus allowing endless possibilities for button shapes
-ImageSequencer:	a widget that animates a sequence of images, can be used while background task is running, etc.
-GoogleMapComposite:	a composite that contains a browser with embedded googlemap page

Fixes:
-CoolSlider resize problem fixed

Samples added:
-CoolGauge demo (with full and half circle gauges)
-GoogleMapComposite demo
-ImageSequencer demo
-Updated demo for Coolbutton, CoolSlider
-Updated demos for PropagateComposite


v0.2 (2007-10-05)
------------------
Widgets added:
-CoolProgressBar: 	a progress bar that can use custom images
-ScrollingLabel:	a Label with scrolling text

Fixes:
-CoolButton:		a problem with some button's statemodel fixed

Samples added:
-CoolButtonDemo
-CoolSliderDemo
-ScrollingLabelDemo
-CoolProgressBarDemo

Build changes:
-Build now build separate binaries (jars) for toolbox library and samples


v0.1 (2007-10-01)
------------------
Widgets added:
-CoolButton: 		a Button replacement widget that allows user to define his own image sets. Works like a Button, but with much more visual appeal
-CoolSlider: 		a Slider replacement, also working with custom image sets. Allows e.g. to create nice looking volume sliders in a media player.
-DigitalClock: 		a customizable digital clock widget, can be used as a time counter, 12 hour clock, or 24 hour clock
-DualListComposite: provides a composite with two lists and Add/Remove buttons for adding items from one list to the other. Can use TableViewers on both sides for more comples lists.
-StringDualList: 	a simple DualListComposite subclass that is easier to use, but only allows client code to specify String lists as input.
-PropagateComposite: a Composite that propagates requests e.g. setEnabled(..) to its child widgets
-PropagateGroup: 	same as PropagateComposite, but extends Group

Samples added:
-DigitalClockDemo: provides sample for DigitalClock
-SimpleDualListSample, StringDualListSample, TableDualListSample: samples for DualList
-PropagateCompositeSample: sample for PropagateComposite
-PropagateGroupSample: sample for PropagateGroup

To run samples:
Use the ant scripts "samples.xml":
ant -f samples.xml <NAME_OF_SAMPLE>